<p align="center"><img src="https://raw.githubusercontent.com/eslamelhefny/AImon/main/logo.png" alt="AI Meter" height="64"></p>

**Your AI fuel gauge, on your own machine.** One page that shows every AI plan limit, when it comes back, and the tokens and cost you used, across Claude, ChatGPT/Codex, Kimi, OpenCode Go, DeepSeek, OpenRouter, Anthropic, OpenAI, Nous and Hermes Agent.

## Install and run

```bash
pipx install ai-meter        # or: pip install ai-meter
aimeter
```

Open http://localhost:8787 and click **Connect a provider**. Paste a key, or sign in for Claude and ChatGPT. No config file to edit.

## What you get

- **When your limits come back:** every 5-hour, weekly and monthly limit on one timeline, with live countdowns.
- **Tokens and cost:** totals for today and the month, across all providers, per provider and per model.
- **Pace warnings:** "At this pace you run out in about 1h 40m".
- **Alerts:** Telegram or any webhook at 50, 80 and 95%.
- **In your editor:** the AI Meter extension for VS Code puts the tightest limit in the status bar and every limit in a side panel.
- **Private by design:** runs on your machine. Keys stay in its local database and are never sent to the browser or the editor.

## Providers

| Provider | What it shows | Connect with |
|---|---|---|
| Claude Pro/Max | 5-hour and weekly limits, reset times | Sign in |
| ChatGPT / Codex | 5-hour and weekly limits | Sign in |
| Kimi Code | 5-hour window, plan quota | API key |
| OpenCode Go | 5-hour, weekly, monthly allowance | API key |
| OpenRouter | Credits, key cap, tokens per model | API key (+ management key) |
| DeepSeek, Kimi API | Prepaid balance | API key |
| Anthropic, OpenAI | Spend, tokens per model, rate limits | Admin key / API key |
| Nous Portal | Rate limits | API key |
| Hermes Agent | Tokens and cost of everything it runs | Path to its state.db |

Claude, ChatGPT, Kimi Code and OpenCode Go are read from the same usage endpoints their own apps use. These are not documented public APIs and may change; when one does, its card shows an error rather than a wrong number.

## Options

```bash
aimeter serve --host 0.0.0.0 --port 8787   # share on your network (set AIMETER_DASHBOARD_TOKEN first)
aimeter status                             # summary in the terminal
aimeter collect --force                    # check every provider now
AIMETER_HOME=/srv/aimeter aimeter          # keep config and data elsewhere (default ~/.aimeter)
```

## Run it on a server with Docker

Use `docker-compose.yaml` from the repository. Config and data live in `/opt/aimeter` on the host. The dashboard listens on `127.0.0.1:8787`; reach it with an SSH tunnel:

```bash
ssh -N -L 8787:127.0.0.1:8787 you@your-server
```

## VS Code

Install **AI Meter** from the VS Code Marketplace (or the `.vsix` from the releases page). It reads from your running AI Meter at `http://localhost:8787`; if you set a dashboard token, run **AI Meter: Set dashboard token** once.

## License

MIT
