#!/usr/bin/env python3
"""
AI Meter: AI plan limits, tokens and cost monitor.

Collects live spend, credits and caps from provider APIs, tracks renewal
dates and manual usage readings for chat subscriptions and other SaaS,
sends alerts (Telegram / webhook) and serves a small web dashboard.

Commands:
  collect            poll every API account, store a snapshot, send alerts
  serve              run the dashboard (default 127.0.0.1:8787)
  status             print a summary in the terminal
  log ID VALUE       record a manual usage reading for a subscription
  test-alert         send a test message to every enabled alert channel
"""
from __future__ import annotations

import argparse
import base64
import datetime as dt
import hmac
import json
import logging
import os
import re
import sqlite3
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import requests
import yaml

UTC = dt.timezone.utc
HERE = Path(__file__).resolve().parent
log = logging.getLogger("aimeter")
HTTP_TIMEOUT = 30


# --------------------------------------------------------------------------
# Config
# --------------------------------------------------------------------------

def load_env_file(path: Path) -> None:
    """Minimal .env loader (KEY=VALUE lines). Existing env vars win."""
    if not path.exists():
        return
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        v = v.strip().strip('"').strip("'")
        os.environ.setdefault(k.strip(), v)


def default_config_path() -> Path:
    """~/.aimeter/config.yaml (or $AIMETER_HOME/config.yaml), created on first run.
    An existing ~/.aimon folder from before the rename keeps being used."""
    env_home = os.environ.get("AIMETER_HOME") or os.environ.get("AIMON_HOME")
    home = Path(env_home or "~/.aimeter").expanduser()
    legacy = Path("~/.aimon").expanduser()
    if not env_home and not home.exists() and (legacy / "config.yaml").exists():
        home = legacy
    p = home / "config.yaml"
    if not p.exists():
        home.mkdir(parents=True, exist_ok=True)
        starter = HERE / "config.starter.yaml"
        p.write_text(starter.read_text() if starter.exists() else "settings: {}\napi_accounts: []\nsubscriptions: []\n")
        log.info("created %s", p)
    return p


def load_config(path: str | None) -> dict:
    cfg_path = Path(path).expanduser() if path else default_config_path()
    load_env_file(cfg_path.parent / ".env")
    with open(cfg_path) as f:
        cfg = yaml.safe_load(f) or {}
    s = cfg.setdefault("settings", {})
    s.setdefault("db_path", "data/monitor.db")
    s.setdefault("alert_thresholds", [0.5, 0.8, 0.95])
    s.setdefault("renewal_reminder_days", [7, 3, 1])
    s.setdefault("fx_to_usd", {"USD": 1})
    s["fx_to_usd"].setdefault("USD", 1)
    s.setdefault("dashboard", {})
    db = Path(s["db_path"])
    s["db_path"] = str(db if db.is_absolute() else cfg_path.parent / db)
    cfg.setdefault("api_accounts", [])
    cfg.setdefault("subscriptions", [])
    cfg.setdefault("alerts", {})
    return cfg


def env(name: str | None) -> str | None:
    """Read an env var; AIMETER_* names also accept the old AIMON_* spelling."""
    if not name:
        return None
    val = os.environ.get(name)
    if val is None and name.startswith("AIMETER_"):
        val = os.environ.get("AIMON_" + name[len("AIMETER_"):])
    return val


# --------------------------------------------------------------------------
# Storage
# --------------------------------------------------------------------------

SCHEMA = """
CREATE TABLE IF NOT EXISTS snapshots (
    id INTEGER PRIMARY KEY,
    ts TEXT NOT NULL,
    account_id TEXT NOT NULL,
    ok INTEGER NOT NULL,
    metrics TEXT,
    error TEXT
);
CREATE INDEX IF NOT EXISTS ix_snap_acct_ts ON snapshots(account_id, ts);
CREATE TABLE IF NOT EXISTS manual_usage (
    id INTEGER PRIMARY KEY,
    ts TEXT NOT NULL,
    sub_id TEXT NOT NULL,
    value REAL NOT NULL,
    unit TEXT,
    lim REAL,
    note TEXT
);
CREATE INDEX IF NOT EXISTS ix_manual_sub_ts ON manual_usage(sub_id, ts);
CREATE TABLE IF NOT EXISTS alerts_sent (
    key TEXT PRIMARY KEY,
    ts TEXT NOT NULL,
    message TEXT
);
CREATE TABLE IF NOT EXISTS kv (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL,
    ts TEXT NOT NULL
);
"""


def db_connect(cfg: dict) -> sqlite3.Connection:
    Path(cfg["settings"]["db_path"]).parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(cfg["settings"]["db_path"], timeout=30)
    con.row_factory = sqlite3.Row
    con.executescript(SCHEMA)
    try:
        os.chmod(cfg["settings"]["db_path"], 0o600)  # holds OAuth tokens
    except OSError:
        pass
    return con


def kv_get(con, key: str):
    row = con.execute("SELECT value FROM kv WHERE key=?", (key,)).fetchone()
    return json.loads(row[0]) if row else None


def kv_set(con, key: str, value) -> None:
    if value is None:
        con.execute("DELETE FROM kv WHERE key=?", (key,))
    else:
        con.execute("INSERT OR REPLACE INTO kv(key, value, ts) VALUES (?,?,?)",
                    (key, json.dumps(value), iso(now_utc())))
    con.commit()


def now_utc() -> dt.datetime:
    return dt.datetime.now(UTC)


def iso(t: dt.datetime) -> str:
    return t.astimezone(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


def latest_snapshot(con, account_id: str, ok_only=False):
    q = "SELECT * FROM snapshots WHERE account_id=?"
    if ok_only:
        q += " AND ok=1"
    row = con.execute(q + " ORDER BY ts DESC LIMIT 1", (account_id,)).fetchone()
    if not row:
        return None
    d = dict(row)
    d["metrics"] = json.loads(d["metrics"]) if d["metrics"] else {}
    return d


def latest_manual(con, sub_id: str):
    row = con.execute(
        "SELECT * FROM manual_usage WHERE sub_id=? ORDER BY ts DESC LIMIT 1", (sub_id,)
    ).fetchone()
    return dict(row) if row else None


# --------------------------------------------------------------------------
# Collectors. Each returns a metrics dict:
#   spend_mtd, spend_today        USD spent this calendar month (UTC) / today
#   daily: [{date, usd}]          per-day spend this month
#   by_model: {name: usd}         spend breakdown
#   tokens_by_model: {name: n}    input+output tokens this month
#   balance                       prepaid credit left (USD), if known
#   cap, cap_remaining            provider-side spending cap, if known
# --------------------------------------------------------------------------

def month_start(t: dt.datetime) -> dt.datetime:
    return t.replace(day=1, hour=0, minute=0, second=0, microsecond=0)


def _get(url, headers, params=None):
    r = requests.get(url, headers=headers, params=params, timeout=HTTP_TIMEOUT)
    if r.status_code >= 400:
        raise RuntimeError(f"HTTP {r.status_code} from {urlparse(url).path}: {r.text[:300]}")
    return r.json()


def _paginate(url, headers, params, next_key="next_page", page_param="page", max_pages=20):
    params = dict(params)
    for _ in range(max_pages):
        data = _get(url, headers, params)
        yield data
        if not data.get("has_more") or not data.get(next_key):
            return
        params[page_param] = data[next_key]


def _finish(daily: dict, by_model: dict, today: str) -> dict:
    return {
        "spend_mtd": round(sum(daily.values()), 4),
        "spend_today": round(daily.get(today, 0.0), 4),
        "daily": [{"date": d, "usd": round(v, 4)} for d, v in sorted(daily.items())],
        "by_model": {k: round(v, 4) for k, v in sorted(by_model.items(), key=lambda x: -x[1])},
    }


# A "window" is one limit a provider enforces, shown as one gauge in a widget:
#   {key, label, used_pct (0-100), resets_at (ISO UTC), window_seconds,
#    limit, remaining, unit}

def window(key, label, used_pct, resets_at=None, window_seconds=None, limit=None, remaining=None, unit=None):
    if isinstance(resets_at, (int, float)):
        resets_at = iso(dt.datetime.fromtimestamp(resets_at, UTC))
    elif isinstance(resets_at, dt.datetime):
        resets_at = iso(resets_at)
    elif isinstance(resets_at, str) and resets_at:
        try:
            resets_at = iso(dt.datetime.fromisoformat(resets_at.replace("Z", "+00:00")))
        except ValueError:
            pass
    return {
        "key": key, "label": label,
        "used_pct": None if used_pct is None else round(max(0.0, min(999.0, float(used_pct))), 1),
        "resets_at": resets_at or None, "window_seconds": window_seconds,
        "limit": limit, "remaining": remaining, "unit": unit,
    }


def next_month_start(t: dt.datetime) -> dt.datetime:
    m = month_start(t)
    return (m + dt.timedelta(days=32)).replace(day=1)


def openrouter_reset(kind):
    now = now_utc()
    midnight = now.replace(hour=0, minute=0, second=0, microsecond=0)
    if kind == "daily":
        return midnight + dt.timedelta(days=1)
    if kind == "weekly":
        return midnight + dt.timedelta(days=7 - now.weekday())
    if kind == "monthly":
        return next_month_start(now)
    return None


def budget_windows(acct: dict, m: dict) -> list:
    out = []
    if acct.get("monthly_budget") and m.get("spend_mtd") is not None:
        b = float(acct["monthly_budget"])
        out.append(window("budget", "Monthly budget", m["spend_mtd"] / b * 100, resets_at=next_month_start(now_utc()),
                          limit=b, remaining=round(b - m["spend_mtd"], 2), unit="USD"))
    if acct.get("daily_budget") and m.get("spend_today") is not None:
        b = float(acct["daily_budget"])
        nxt = now_utc().replace(hour=0, minute=0, second=0, microsecond=0) + dt.timedelta(days=1)
        out.append(window("daily", "Daily budget", m["spend_today"] / b * 100, resets_at=nxt,
                          limit=b, remaining=round(b - m["spend_today"], 2), unit="USD"))
    return out


class TokenAgg:
    """Collects token counts and cost per model and per day into one shape:
    token_usage = {totals, today, by_model[], daily[]} (totals = this calendar month, UTC)."""
    FIELDS = ("input", "output", "cache", "reasoning", "cost", "requests")

    def __init__(self, now=None):
        now = now or now_utc()
        self.today = now.strftime("%Y-%m-%d")
        self.month = now.strftime("%Y-%m")
        self.models, self.days = {}, {}
        self.tot = dict.fromkeys(self.FIELDS, 0.0)
        self.td = dict.fromkeys(self.FIELDS, 0.0)
        self.has_cost = False

    def add(self, day, model, input=0, output=0, cache=0, reasoning=0, cost=None, requests=0):
        vals = {"input": input or 0, "output": output or 0, "cache": cache or 0, "reasoning": reasoning or 0,
                "cost": cost or 0, "requests": requests or 0}
        if cost is not None:
            self.has_cost = True
        d = self.days.setdefault(day, {"tokens": 0, "cost": 0.0})
        d["tokens"] += vals["input"] + vals["output"] + vals["cache"]
        d["cost"] += vals["cost"]
        if not day.startswith(self.month):
            return
        m = self.models.setdefault(model or "other", dict.fromkeys(self.FIELDS, 0.0))
        for k, v in vals.items():
            m[k] += v
            self.tot[k] += v
            if day == self.today:
                self.td[k] += v

    def set_model_cost(self, model, cost):
        if model in self.models:
            self.models[model]["cost"] = cost
            self.has_cost = True

    def result(self, source=None):
        def clean(x):
            out = {k: (round(v, 4) if k == "cost" else int(v)) for k, v in x.items()}
            if not self.has_cost:
                out["cost"] = None
            return out
        rows = [{"model": k, **clean(v)} for k, v in self.models.items()]
        rows.sort(key=lambda r: -((r["input"] + r["output"] + r["cache"]) or 0))
        return {"source": source, "totals": clean(self.tot), "today": clean(self.td), "by_model": rows,
                "daily": [{"date": d, "tokens": int(v["tokens"]), "cost": round(v["cost"], 4)}
                          for d, v in sorted(self.days.items())]}


def collect_anthropic(acct: dict, con=None) -> dict:
    """Anthropic Admin API (needs an sk-ant-admin... key)."""
    key = env(acct.get("api_key_env"))
    if not key:
        raise RuntimeError(f"env var {acct.get('api_key_env')} is not set")
    h = {"x-api-key": key, "anthropic-version": "2023-06-01", "User-Agent": "aimeter/1.0"}
    base = acct.get("base_url", "https://api.anthropic.com")
    now = now_utc()
    start = month_start(now)
    today = now.strftime("%Y-%m-%d")

    daily, by_model = {}, {}
    params = {
        "starting_at": iso(start),
        "ending_at": iso(now + dt.timedelta(days=1)),
        "group_by[]": "description",
        "limit": 31,
    }
    for page in _paginate(f"{base}/v1/organizations/cost_report", h, params):
        for bucket in page.get("data", []):
            day = str(bucket.get("starting_at", ""))[:10]
            for res in bucket.get("results", []):
                usd = float(res.get("amount") or 0) / 100.0  # amounts are in cents
                daily[day] = daily.get(day, 0.0) + usd
                name = res.get("model") or res.get("description") or res.get("cost_type") or "other"
                by_model[name] = by_model.get(name, 0.0) + usd
    out = _finish(daily, by_model, today)

    agg = TokenAgg(now)
    try:
        uparams = {
            "starting_at": iso(start),
            "ending_at": iso(now + dt.timedelta(days=1)),
            "group_by[]": "model",
            "bucket_width": "1d",
            "limit": 31,
        }
        for page in _paginate(f"{base}/v1/organizations/usage_report/messages", h, uparams):
            for bucket in page.get("data", []):
                day = str(bucket.get("starting_at", ""))[:10]
                for res in bucket.get("results", []):
                    cc = res.get("cache_creation") or {}
                    agg.add(day, res.get("model") or "other",
                            input=res.get("uncached_input_tokens") or 0,
                            output=res.get("output_tokens") or 0,
                            cache=(res.get("cache_read_input_tokens") or 0)
                            + sum(v or 0 for v in cc.values() if isinstance(v, (int, float))))
        for m, usd in out["by_model"].items():
            agg.set_model_cost(m, usd)
        out["token_usage"] = agg.result("Anthropic usage report")
    except Exception as e:  # tokens are a nice-to-have
        log.warning("anthropic usage_report failed: %s", e)
    out["windows"] = budget_windows(acct, out)
    return out


def collect_openai(acct: dict, con=None) -> dict:
    """OpenAI Platform org Usage/Costs API (needs an admin key)."""
    key = env(acct.get("api_key_env"))
    if not key:
        raise RuntimeError(f"env var {acct.get('api_key_env')} is not set")
    h = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
    if acct.get("org_id"):
        h["OpenAI-Organization"] = acct["org_id"]
    base = acct.get("base_url", "https://api.openai.com")
    now = now_utc()
    start = int(month_start(now).timestamp())
    today = now.strftime("%Y-%m-%d")

    daily, by_line = {}, {}
    params = {"start_time": start, "bucket_width": "1d", "limit": 31, "group_by": "line_item"}
    for page in _paginate(f"{base}/v1/organization/costs", h, params):
        for bucket in page.get("data", []):
            day = dt.datetime.fromtimestamp(bucket.get("start_time", 0), UTC).strftime("%Y-%m-%d")
            for res in bucket.get("results", []):
                amt = res.get("amount") or {}
                usd = float(amt.get("value") or 0)
                daily[day] = daily.get(day, 0.0) + usd
                name = res.get("line_item") or "other"
                by_line[name] = by_line.get(name, 0.0) + usd
    out = _finish(daily, by_line, today)

    try:
        agg = TokenAgg(now)
        uparams = {"start_time": start, "bucket_width": "1d", "limit": 31, "group_by": "model"}
        for page in _paginate(f"{base}/v1/organization/usage/completions", h, uparams):
            for bucket in page.get("data", []):
                day = dt.datetime.fromtimestamp(bucket.get("start_time", 0), UTC).strftime("%Y-%m-%d")
                for res in bucket.get("results", []):
                    cached = res.get("input_cached_tokens") or 0
                    agg.add(day, res.get("model") or "other",
                            input=(res.get("input_tokens") or 0) - cached, output=res.get("output_tokens") or 0,
                            cache=cached, requests=res.get("num_model_requests") or 0)
        tu = agg.result("OpenAI usage API")
        tu["totals"]["cost"] = out["spend_mtd"]  # cost comes per line item, not per model
        tu["today"]["cost"] = out["spend_today"]
        day_cost = {d["date"]: d["usd"] for d in out["daily"]}
        for d in tu["daily"]:
            d["cost"] = day_cost.get(d["date"], 0.0)
        out["token_usage"] = tu
    except Exception as e:
        log.warning("openai usage/completions failed: %s", e)
    out["windows"] = budget_windows(acct, out)
    return out


def collect_openrouter(acct: dict, con=None) -> dict:
    key = env(acct.get("api_key_env"))
    if not key:
        raise RuntimeError(f"env var {acct.get('api_key_env')} is not set")
    h = {"Authorization": f"Bearer {key}"}
    k = _get("https://openrouter.ai/api/v1/key", h).get("data", {})
    today = now_utc().strftime("%Y-%m-%d")
    out = {
        "spend_mtd": round(float(k.get("usage_monthly") or 0), 4),
        "spend_today": round(float(k.get("usage_daily") or 0), 4),
        "spend_all_time": round(float(k.get("usage") or 0), 4),
        "daily": [{"date": today, "usd": round(float(k.get("usage_daily") or 0), 4)}],
        "by_model": {},
        "cap": k.get("limit"),
        "cap_remaining": k.get("limit_remaining"),
        "cap_reset": k.get("limit_reset"),
        "free_tier": k.get("is_free_tier"),
    }
    try:
        c = _get("https://openrouter.ai/api/v1/credits", h).get("data", {})
        out["balance"] = round(float(c.get("total_credits", 0)) - float(c.get("total_usage", 0)), 4)
    except Exception as e:
        log.info("openrouter /credits unavailable for this key: %s", e)
    mkey = env(acct.get("management_key_env"))
    if mkey:  # per-model tokens + cost for the last 30 days (management keys only)
        try:
            act = _get("https://openrouter.ai/api/v1/activity", {"Authorization": f"Bearer {mkey}"}).get("data") or []
            agg = TokenAgg()
            for r in act:
                agg.add(r.get("date", ""), r.get("model") or r.get("model_permaslug"),
                        input=r.get("prompt_tokens") or 0, output=r.get("completion_tokens") or 0,
                        reasoning=r.get("reasoning_tokens") or 0,
                        cost=float(r.get("usage") or 0) + float(r.get("byok_usage_inference") or 0),
                        requests=r.get("requests") or 0)
            tu = agg.result("OpenRouter activity (completed days)")
            tu["today"]["cost"] = out["spend_today"]  # activity covers completed days only
            out["token_usage"] = tu
        except Exception as e:
            out["token_note"] = f"activity API: {str(e)[:120]}"
    w = []
    if k.get("limit"):
        lim, rem = float(k["limit"]), float(k.get("limit_remaining") or 0)
        w.append(window("cap", f"Key cap ({k.get('limit_reset') or 'total'})", (1 - rem / lim) * 100 if lim else None,
                        resets_at=openrouter_reset(k.get("limit_reset")), limit=lim, remaining=rem, unit="USD"))
    w += budget_windows(acct, out)
    rl = k.get("rate_limit") or {}
    if rl.get("requests"):
        out["rate_limit"] = f"{rl['requests']} requests / {rl.get('interval', '')}"
    out["windows"] = w
    return out


def collect_deepseek(acct: dict, con=None) -> dict:
    key = env(acct.get("api_key_env"))
    if not key:
        raise RuntimeError(f"env var {acct.get('api_key_env')} is not set")
    d = _get("https://api.deepseek.com/user/balance", {"Authorization": f"Bearer {key}"})
    infos = d.get("balance_infos") or []
    usd = next((i for i in infos if i.get("currency") == "USD"), infos[0] if infos else {})
    return {
        "balance": float(usd.get("total_balance") or 0),
        "balance_currency": usd.get("currency", "USD"),
        "available": d.get("is_available"),
    }


def collect_manual(acct: dict, con=None) -> dict:
    """For providers with no usage API: numbers come from `aimeter log`."""
    return {"manual": True}


# --------------------------------------------------------------------------
# Subscription plan limits (Claude Pro/Max, ChatGPT/Codex).
# These use the same private endpoints the official CLIs use for /usage and
# /status. They are not public APIs and may change. AI Meter gets its own login
# through the dashboard's Connect button (OAuth with PKCE), so it never
# shares, or logs out, the tokens of your laptop's CLI.
# --------------------------------------------------------------------------

class NotConnected(RuntimeError):
    pass


OAUTH = {
    "claude_sub": {
        "client_id": "9d1c250a-e61b-44d9-88ed-5944d1962f5e",
        "authorize": "https://claude.ai/oauth/authorize",
        "token_urls": ["https://platform.claude.com/v1/oauth/token", "https://console.anthropic.com/v1/oauth/token"],
        "redirect": "https://console.anthropic.com/oauth/code/callback",
        "scope": "user:profile user:inference",
        "extra": {"code": "true"},
        "json_body": True,
        "hint": "After you approve, the page shows a code. Copy all of it and paste it here.",
    },
    "codex_sub": {
        "client_id": "app_EMoamEEZ73f0CkXaXp7hrann",
        "authorize": "https://auth.openai.com/oauth/authorize",
        "token_urls": ["https://auth.openai.com/oauth/token"],
        "redirect": "http://localhost:1455/auth/callback",
        "scope": "openid profile email offline_access",
        "extra": {"id_token_add_organizations": "true", "codex_cli_simplified_flow": "true"},
        "json_body": False,
        "hint": "After you sign in, the browser opens a page that fails to load (localhost:1455). "
                "That is expected: copy the full address from the address bar and paste it here.",
    },
}


def _b64url(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def oauth_start(con, acct: dict) -> dict:
    import hashlib
    import secrets
    from urllib.parse import urlencode
    o = OAUTH[acct["provider"]]
    verifier = _b64url(secrets.token_bytes(32))
    state = _b64url(secrets.token_bytes(16))
    challenge = _b64url(hashlib.sha256(verifier.encode()).digest())
    kv_set(con, f"oauth_pending:{acct['id']}", {"verifier": verifier, "state": state})
    q = {"response_type": "code", "client_id": o["client_id"], "redirect_uri": o["redirect"], "scope": o["scope"],
         "code_challenge": challenge, "code_challenge_method": "S256", "state": state, **o["extra"]}
    return {"url": o["authorize"] + "?" + urlencode(q), "hint": o["hint"]}


def _token_post(o: dict, body: dict) -> dict:
    last = None
    for url in o["token_urls"]:
        try:
            if o["json_body"]:
                r = requests.post(url, json=body, timeout=HTTP_TIMEOUT, headers={"User-Agent": "aimeter/1.0"})
            else:
                r = requests.post(url, data=body, timeout=HTTP_TIMEOUT, headers={"User-Agent": "aimeter/1.0"})
            if r.ok:
                return r.json()
            last = f"HTTP {r.status_code}: {r.text[:200]}"
        except requests.RequestException as e:
            last = str(e)
    raise RuntimeError(f"token request failed ({last})")


def _jwt_claims(token: str) -> dict:
    try:
        part = token.split(".")[1]
        return json.loads(base64.urlsafe_b64decode(part + "=" * (-len(part) % 4)))
    except Exception:
        return {}


def _save_tokens(con, acct, tok: dict, old: dict | None = None) -> dict:
    old = old or {}
    rec = {
        "access_token": tok["access_token"],
        "refresh_token": tok.get("refresh_token") or old.get("refresh_token"),
        "expires_at": int(now_utc().timestamp()) + int(tok.get("expires_in") or 3600),
        "account_id": old.get("account_id"),
        "email": old.get("email"),
    }
    for t in (tok.get("id_token"), tok.get("access_token")):
        c = _jwt_claims(t or "")
        auth = c.get("https://api.openai.com/auth") or {}
        rec["account_id"] = auth.get("chatgpt_account_id") or rec["account_id"]
        rec["plan"] = auth.get("chatgpt_plan_type") or rec.get("plan") or old.get("plan")
        rec["email"] = c.get("email") or rec["email"]
    if isinstance(tok.get("account"), dict):
        rec["email"] = tok["account"].get("email_address") or rec["email"]
    kv_set(con, f"oauth:{acct['id']}", rec)
    return rec


def oauth_finish(con, acct: dict, pasted: str) -> dict:
    from urllib.parse import parse_qs as _pq
    o = OAUTH[acct["provider"]]
    pend = kv_get(con, f"oauth_pending:{acct['id']}")
    if not pend:
        raise RuntimeError("No login in progress. Click Connect again.")
    pasted = pasted.strip()
    code, state = pasted, pend["state"]
    if pasted.startswith("http"):
        q = _pq(urlparse(pasted).query)
        code = (q.get("code") or [""])[0]
        state = (q.get("state") or [state])[0]
    elif "#" in pasted:
        code, state = pasted.split("#", 1)
    if not code:
        raise RuntimeError("Could not find a code in what you pasted.")
    if state != pend["state"]:
        raise RuntimeError("This code belongs to an older login attempt. Click Connect again.")
    body = {"grant_type": "authorization_code", "code": code, "client_id": o["client_id"],
            "redirect_uri": o["redirect"], "code_verifier": pend["verifier"]}
    if acct["provider"] == "claude_sub":
        body["state"] = state
    tok = _token_post(o, body)
    kv_set(con, f"oauth_pending:{acct['id']}", None)
    return _save_tokens(con, acct, tok)


def oauth_token(con, acct: dict) -> dict:
    rec = kv_get(con, f"oauth:{acct['id']}") if con is not None else None
    if not rec:
        tok = env(acct.get("access_token_env"))  # manual fallback: paste an access token
        if tok:
            return {"access_token": tok, "account_id": env(acct.get("account_id_env"))}
        raise NotConnected("Not connected yet. Click Connect in this widget.")
    if rec.get("expires_at", 0) - 300 < now_utc().timestamp() and rec.get("refresh_token"):
        o = OAUTH[acct["provider"]]
        body = {"grant_type": "refresh_token", "refresh_token": rec["refresh_token"], "client_id": o["client_id"]}
        if acct["provider"] == "codex_sub":
            body["scope"] = "openid profile email"
        try:
            rec = _save_tokens(con, acct, _token_post(o, body), rec)
        except RuntimeError as e:
            raise NotConnected(f"Login expired and refresh failed, click Reconnect. ({e})")
    return rec


def _window_label(seconds, fallback):
    s = int(seconds or 0)
    if s == 18000:
        return "5-hour session"
    if s == 604800:
        return "Weekly"
    if s == 86400:
        return "Daily"
    if s:
        return f"{round(s / 3600)}h window" if s < 172800 else f"{round(s / 86400)}-day window"
    return fallback


CLAUDE_WINDOWS = {
    "five_hour": ("5-hour session", 18000), "seven_day": ("Weekly (all models)", 604800),
    "seven_day_opus": ("Weekly Opus", 604800), "seven_day_sonnet": ("Weekly Sonnet", 604800),
    "seven_day_oauth_apps": ("Weekly (apps)", 604800),
}


def collect_claude_sub(acct: dict, con=None) -> dict:
    tok = oauth_token(con, acct)
    r = requests.get("https://api.anthropic.com/api/oauth/usage", timeout=HTTP_TIMEOUT, headers={
        "Authorization": f"Bearer {tok['access_token']}", "anthropic-beta": "oauth-2025-04-20",
        "Content-Type": "application/json", "User-Agent": "aimeter/1.0"})
    if r.status_code in (401, 403):
        raise NotConnected(f"Claude rejected the login (HTTP {r.status_code}), click Reconnect.")
    if r.status_code >= 400:
        raise RuntimeError(f"HTTP {r.status_code}: {r.text[:200]}")
    d = r.json()
    wins = []
    for k, v in d.items():
        if isinstance(v, dict) and "utilization" in v and v.get("utilization") is not None:
            label, secs = CLAUDE_WINDOWS.get(k, (k.replace("_", " ").capitalize(), None))
            wins.append(window(k, label, v["utilization"], resets_at=v.get("resets_at"), window_seconds=secs))
    ex = d.get("extra_usage") or {}
    if ex.get("is_enabled") and ex.get("monthly_limit"):
        used, lim = float(ex.get("used_credits") or 0), float(ex["monthly_limit"])
        wins.append(window("extra", "Extra usage", ex.get("utilization", used / lim * 100 if lim else 0),
                           resets_at=next_month_start(now_utc()), limit=lim / 100, remaining=(lim - used) / 100,
                           unit="USD"))
    order = list(CLAUDE_WINDOWS)
    wins.sort(key=lambda w: order.index(w["key"]) if w["key"] in order else 99)
    return {"windows": wins, "account": tok.get("email"), "plan": acct.get("plan")}


def _codex_windows(rl: dict, prefix: str, name: str | None = None) -> list:
    out = []
    for slot in ("primary_window", "secondary_window"):
        w = (rl or {}).get(slot)
        if not isinstance(w, dict) or w.get("used_percent") is None:
            continue
        secs = w.get("limit_window_seconds")
        reset = w.get("reset_at")
        if not reset and w.get("reset_after_seconds") is not None:
            reset = now_utc().timestamp() + float(w["reset_after_seconds"])
        label = _window_label(secs, slot.split("_")[0].capitalize())
        out.append(window(f"{prefix}_{slot}", f"{name}: {label}" if name else label, w["used_percent"],
                          resets_at=reset, window_seconds=secs))
    return out


def collect_codex_sub(acct: dict, con=None) -> dict:
    tok = oauth_token(con, acct)
    h = {"Authorization": f"Bearer {tok['access_token']}", "User-Agent": "codex-cli", "Accept": "application/json"}
    if tok.get("account_id"):
        h["ChatGPT-Account-Id"] = tok["account_id"]
    r = requests.get("https://chatgpt.com/backend-api/wham/usage", headers=h, timeout=HTTP_TIMEOUT)
    if r.status_code in (401, 403):
        raise NotConnected(f"ChatGPT rejected the login (HTTP {r.status_code}), click Reconnect.")
    if r.status_code >= 400:
        raise RuntimeError(f"HTTP {r.status_code}: {r.text[:200]}")
    d = r.json()
    wins = _codex_windows(d.get("rate_limit"), "codex")
    for extra in d.get("additional_rate_limits") or []:
        name = extra.get("limit_name") or extra.get("metered_feature") or "Model"
        wins += _codex_windows(extra.get("rate_limit"), re.sub(r"\W+", "_", name.lower()), name)
    if d.get("code_review_rate_limit"):
        wins += _codex_windows(d["code_review_rate_limit"], "review", "Code review")
    out = {"windows": wins, "plan": d.get("plan_type") or tok.get("plan"), "account": tok.get("email")}
    cr = d.get("credits") or {}
    if cr.get("has_credits") and cr.get("balance") is not None:
        out["credits"] = cr.get("balance")
    return out


# --------------------------------------------------------------------------
# API rate limits (tokens/requests per minute) read from response headers.
# Each check sends one tiny request (1 output token), a fraction of a cent.
# --------------------------------------------------------------------------

def _dur_seconds(s: str | None) -> float | None:
    """OpenAI reset values look like '1s', '6m0s', '20ms', '1h2m3.5s'."""
    if not s:
        return None
    total, found = 0.0, False
    for num, unit in re.findall(r"([\d.]+)(ms|h|m|s)", s):
        found = True
        total += float(num) * {"ms": 0.001, "s": 1, "m": 60, "h": 3600}[unit]
    return total if found else None


def _int(v):
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return None


def collect_anthropic_limits(acct: dict, con=None) -> dict:
    key = env(acct.get("api_key_env"))
    if not key:
        raise RuntimeError(f"env var {acct.get('api_key_env')} is not set")
    r = requests.post(f"{acct.get('base_url', 'https://api.anthropic.com')}/v1/messages", timeout=HTTP_TIMEOUT,
                      headers={"x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"},
                      json={"model": acct.get("probe_model", "claude-haiku-5-5"), "max_tokens": 1,
                            "messages": [{"role": "user", "content": "1"}]})
    h = r.headers
    if r.status_code >= 400 and r.status_code != 429 and not h.get("anthropic-ratelimit-requests-limit"):
        raise RuntimeError(f"HTTP {r.status_code}: {r.text[:200]}")
    wins = []
    for k, label, unit in (("requests", "Requests / min", "requests"), ("input-tokens", "Input tokens / min", "tokens"),
                           ("output-tokens", "Output tokens / min", "tokens"), ("tokens", "Tokens / min", "tokens")):
        lim, rem = _int(h.get(f"anthropic-ratelimit-{k}-limit")), _int(h.get(f"anthropic-ratelimit-{k}-remaining"))
        if lim:
            wins.append(window(k, label, (1 - (rem or 0) / lim) * 100, resets_at=h.get(f"anthropic-ratelimit-{k}-reset"),
                               window_seconds=60, limit=lim, remaining=rem, unit=unit))
    if any(w["key"] in ("input-tokens", "output-tokens") for w in wins):
        wins = [w for w in wins if w["key"] != "tokens"]
    return {"windows": wins, "model": acct.get("probe_model", "claude-haiku-5-5"),
            "throttled": r.status_code == 429}


def collect_openai_limits(acct: dict, con=None) -> dict:
    key = env(acct.get("api_key_env"))
    if not key:
        raise RuntimeError(f"env var {acct.get('api_key_env')} is not set")
    model = acct.get("probe_model")
    if not model:
        raise RuntimeError("set probe_model in config.yaml (any cheap chat model your key can use)")
    r = requests.post(f"{acct.get('base_url', 'https://api.openai.com')}/v1/chat/completions", timeout=HTTP_TIMEOUT,
                      headers={"Authorization": f"Bearer {key}"},
                      json={"model": model, "max_completion_tokens": 1, "messages": [{"role": "user", "content": "1"}]})
    h = r.headers
    if r.status_code >= 400 and r.status_code != 429 and not h.get("x-ratelimit-limit-requests"):
        raise RuntimeError(f"HTTP {r.status_code}: {r.text[:200]}")
    wins = []
    for k, label, unit in (("requests", "Requests / min", "requests"), ("tokens", "Tokens / min", "tokens")):
        lim, rem = _int(h.get(f"x-ratelimit-limit-{k}")), _int(h.get(f"x-ratelimit-remaining-{k}"))
        if lim:
            secs = _dur_seconds(h.get(f"x-ratelimit-reset-{k}"))
            reset = now_utc() + dt.timedelta(seconds=secs) if secs is not None else None
            wins.append(window(k, label, (1 - (rem or 0) / lim) * 100, resets_at=reset, window_seconds=60,
                               limit=lim, remaining=rem, unit=unit))
    return {"windows": wins, "model": model, "throttled": r.status_code == 429}


def collect_hermes(acct: dict, con=None) -> dict:
    """Token counts and cost per model from Hermes Agent's own session database.
    Covers every provider Hermes routes to (Nous, DeepSeek, Kimi, OpenCode Go, ...)."""
    path = acct.get("state_db", "/hermes/state.db")
    if not Path(path).exists():
        raise RuntimeError(f"Hermes database not found at {path} (is the Hermes volume mounted?)")
    h = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=10)
    h.row_factory = sqlite3.Row
    cols = {r[1] for r in h.execute("PRAGMA table_info(sessions)")}
    def c(name, default="0"):
        return f"COALESCE({name},0)" if name in cols else default
    cost = ("COALESCE(actual_cost_usd, estimated_cost_usd, 0)" if "actual_cost_usd" in cols
            else c("estimated_cost_usd"))
    prov = "billing_provider" if "billing_provider" in cols else "NULL"
    since = (month_start(now_utc()) - dt.timedelta(days=31)).timestamp()
    rows = h.execute(f"""
        SELECT date(started_at, 'unixepoch') AS day, COALESCE(model, 'unknown') AS model, {prov} AS provider,
               SUM({c('input_tokens')}) AS i, SUM({c('output_tokens')}) AS o,
               SUM({c('cache_read_tokens')} + {c('cache_write_tokens')}) AS ca,
               SUM({c('reasoning_tokens')}) AS r, SUM({cost}) AS cost,
               SUM({c('api_call_count', c('message_count'))}) AS req, COUNT(*) AS sessions
        FROM sessions WHERE started_at >= ? GROUP BY day, model, provider""", (since,)).fetchall()
    hourly = h.execute(f"""
        SELECT strftime('%Y-%m-%dT%H', started_at, 'unixepoch') AS hr, COALESCE({prov}, '') AS provider,
               COALESCE(model, '') AS model,
               SUM({c('input_tokens')} + {c('output_tokens')} + {c('cache_read_tokens')} + {c('cache_write_tokens')}) AS tok,
               SUM({cost}) AS cost
        FROM sessions WHERE started_at >= ? GROUP BY hr, provider, model""",
        ((now_utc() - dt.timedelta(days=32)).timestamp(),)).fetchall()
    h.close()
    agg = TokenAgg()
    providers = {}
    for r in rows:
        label = f"{r['model']} ({r['provider']})" if r["provider"] else r["model"]
        agg.add(r["day"], label, input=r["i"], output=r["o"], cache=r["ca"], reasoning=r["r"],
                cost=r["cost"], requests=r["req"])
        if r["day"].startswith(agg.month):
            p = providers.setdefault(r["provider"] or "unknown", {"tokens": 0, "cost": 0.0})
            p["tokens"] += (r["i"] or 0) + (r["o"] or 0) + (r["ca"] or 0)
            p["cost"] += r["cost"] or 0
    tu = agg.result("Hermes sessions")
    tu["by_provider"] = [{"provider": k, "tokens": int(v["tokens"]), "cost": round(v["cost"], 4)}
                         for k, v in sorted(providers.items(), key=lambda x: -x[1]["tokens"])]
    t = tu["totals"]
    return {"token_usage": tu, "spend_mtd": t["cost"], "spend_today": tu["today"]["cost"],
            "hourly": [[r["hr"], r["provider"], r["model"], int(r["tok"] or 0), round(r["cost"] or 0, 5)] for r in hourly],
            "windows": budget_windows(acct, {"spend_mtd": t["cost"], "spend_today": tu["today"]["cost"]})}


def _num(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return None


KIMI_UNITS = {"TIME_UNIT_SECOND": 1, "TIME_UNIT_MINUTE": 60, "TIME_UNIT_HOUR": 3600, "TIME_UNIT_DAY": 86400}


def collect_kimi_code(acct: dict, con=None) -> dict:
    """Kimi Code plan: 5-hour window + plan quota. Uses a Kimi Code API key (console)."""
    key = env(acct.get("api_key_env"))
    if not key:
        raise RuntimeError(f"env var {acct.get('api_key_env')} is not set")
    d = _get(acct.get("usage_url_api", "https://api.kimi.com/coding/v1/usages"),
             {"Authorization": f"Bearer {key}", "User-Agent": "aimeter/1.0"})
    wins = []
    for i, item in enumerate(d.get("limits") or []):
        w, det = item.get("window") or {}, item.get("detail") or {}
        secs = (_num(w.get("duration")) or 0) * KIMI_UNITS.get(w.get("timeUnit"), 60)
        lim, rem = _num(det.get("limit")), _num(det.get("remaining"))
        if lim:
            wins.append(window(f"limit{i}", _window_label(secs, "Window"), (lim - (rem or 0)) / lim * 100,
                               resets_at=det.get("resetTime"), window_seconds=int(secs) or None,
                               limit=lim, remaining=rem, unit="%" if lim == 100 else "units"))
    u = d.get("usage") or {}
    lim, rem = _num(u.get("limit")), _num(u.get("remaining"))
    if lim:
        wins.append(window("quota", acct.get("quota_label", "Plan quota"), (lim - (rem or 0)) / lim * 100,
                           resets_at=u.get("resetTime"), window_seconds=None,
                           limit=lim, remaining=rem, unit="%" if lim == 100 else "units"))
    for w in wins:  # values are percentages of the plan, so the "x of 100 left" line adds nothing
        if w["unit"] == "%":
            w["limit"] = w["remaining"] = None
    return {"windows": wins, "plan": acct.get("plan")}


def collect_kimi_api(acct: dict, con=None) -> dict:
    """Moonshot / Kimi Open Platform prepaid balance."""
    key = env(acct.get("api_key_env"))
    if not key:
        raise RuntimeError(f"env var {acct.get('api_key_env')} is not set")
    base = acct.get("base_url", "https://api.moonshot.ai")
    d = _get(f"{base}/v1/users/me/balance", {"Authorization": f"Bearer {key}"}).get("data") or {}
    cur = acct.get("currency", "CNY" if ".cn" in base else "USD")
    out = {"balance": _num(d.get("available_balance")), "balance_currency": cur,
           "voucher": _num(d.get("voucher_balance")), "cash": _num(d.get("cash_balance"))}
    return out


def _pct(v):
    v = _num(v)
    if v is None:
        return None
    return v * 100 if 0 < v <= 1 and not float(v).is_integer() else v


def collect_opencode_go(acct: dict, con=None) -> dict:
    """OpenCode Go plan: rolling 5-hour, weekly and monthly dollar allowances."""
    key = env(acct.get("api_key_env"))
    if not key:
        raise RuntimeError(f"env var {acct.get('api_key_env')} is not set")
    d = _get("https://opencode.ai/zen/go/v1/usage", {"Authorization": f"Bearer {key}", "User-Agent": "aimeter/1.0"})
    u = d.get("usage") or d
    labels = [("rolling", "5-hour", 18000), ("weekly", "Weekly", 604800), ("monthly", "Monthly", 2592000)]
    caps = acct.get("caps_usd") or {}
    wins = []
    for k, label, secs in labels:
        w = u.get(k) or u.get(f"{k}Usage")
        if not isinstance(w, dict):
            continue
        pct = _pct(w.get("percent", w.get("usagePercent")))
        reset = w.get("resetsAt") or w.get("resetAt")
        if not reset and w.get("resetInSec") is not None:
            reset = now_utc().timestamp() + float(w["resetInSec"])
        if isinstance(reset, (int, float)) and reset > 1e12:  # milliseconds
            reset = reset / 1000
        cap = caps.get(k)
        wins.append(window(k, label, pct, resets_at=reset, window_seconds=secs,
                           limit=cap, remaining=None if cap is None or pct is None else round(cap * (1 - pct / 100), 2),
                           unit="USD" if cap else None))
    if not wins:
        raise RuntimeError(f"unexpected response: {json.dumps(d)[:200]}")
    return {"windows": wins, "plan": acct.get("plan", "Go")}


def collect_nous(acct: dict, con=None) -> dict:
    """Nous Portal has no public usage API; read rate-limit headers from one tiny request."""
    acct = {"base_url": "https://inference-api.nousresearch.com", **acct}
    try:
        out = collect_openai_limits(acct, con)
    except RuntimeError as e:
        if "probe_model" in str(e):
            raise
        raise RuntimeError(f"Nous request failed: {e}")
    if not out["windows"]:
        out["note"] = "Nous did not report rate limits on this request. Credits are only visible in the Portal."
    return out


COLLECTORS = {
    "anthropic": collect_anthropic,
    "openai": collect_openai,
    "openrouter": collect_openrouter,
    "deepseek": collect_deepseek,
    "manual": collect_manual,
    "claude_sub": collect_claude_sub,
    "codex_sub": collect_codex_sub,
    "anthropic_limits": collect_anthropic_limits,
    "openai_limits": collect_openai_limits,
    "kimi_code": collect_kimi_code,
    "kimi_api": collect_kimi_api,
    "opencode_go": collect_opencode_go,
    "nous": collect_nous,
    "hermes": collect_hermes,
}

# How often each provider is polled by default (seconds); override with `interval:`.
DEFAULT_INTERVAL = {
    "anthropic": 1800, "openai": 1800, "openrouter": 300, "deepseek": 1800, "manual": 3600,
    "claude_sub": 300, "codex_sub": 300, "anthropic_limits": 600, "openai_limits": 600,
    "kimi_code": 300, "kimi_api": 1800, "opencode_go": 300, "nous": 900, "hermes": 300,
}

PROVIDER_META = {
    "anthropic": ("Anthropic API", "spend"), "openai": ("OpenAI API", "spend"),
    "openrouter": ("OpenRouter", "spend"), "deepseek": ("DeepSeek", "spend"), "manual": ("Manual", "manual"),
    "claude_sub": ("Claude plan", "plan"), "codex_sub": ("ChatGPT / Codex plan", "plan"),
    "anthropic_limits": ("Anthropic rate limits", "ratelimit"), "openai_limits": ("OpenAI rate limits", "ratelimit"),
    "kimi_code": ("Kimi Code plan", "plan"), "kimi_api": ("Kimi API (Moonshot)", "spend"),
    "opencode_go": ("OpenCode Go plan", "plan"), "nous": ("Nous Portal", "ratelimit"), "hermes": ("Hermes Agent usage", "spend"),
}


# --------------------------------------------------------------------------
# Subscriptions
# --------------------------------------------------------------------------

CYCLE_MONTHS = {"monthly": 1, "quarterly": 3, "semiannual": 6, "yearly": 12, "annual": 12}


def add_months(d: dt.date, n: int) -> dt.date:
    m = d.month - 1 + n
    y, m = d.year + m // 12, m % 12 + 1
    for day in (d.day, 30, 29, 28):
        try:
            return dt.date(y, m, min(day, 31))
        except ValueError:
            continue
    raise ValueError(d)


def next_renewal(sub: dict, today: dt.date | None = None) -> dt.date | None:
    r = sub.get("renews_on")
    if not r:
        return None
    d = r if isinstance(r, dt.date) else dt.date.fromisoformat(str(r))
    today = today or dt.date.today()
    cycle = str(sub.get("cycle", "monthly")).lower()
    if cycle == "weekly":
        while d < today:
            d += dt.timedelta(days=7)
        return d
    step = CYCLE_MONTHS.get(cycle)
    if not step:
        return d
    while d < today:
        d = add_months(d, step)
    return d


def monthly_cost_usd(sub: dict, fx: dict) -> float | None:
    cost = sub.get("cost")
    if cost is None:
        return None
    cur = str(sub.get("currency", "USD")).upper()
    rate = fx.get(cur)
    if rate is None:
        return None
    cycle = str(sub.get("cycle", "monthly")).lower()
    per_month = float(cost) * (52 / 12 if cycle == "weekly" else 1 / CYCLE_MONTHS.get(cycle, 1))
    return round(per_month * float(rate), 2)


def usage_period_key(sub: dict, t: dt.datetime) -> str:
    p = str(sub.get("limit_period", "monthly")).lower()
    if p == "weekly":
        y, w, _ = t.isocalendar()
        return f"{y}-W{w:02d}"
    if p == "daily":
        return t.strftime("%Y-%m-%d")
    return t.strftime("%Y-%m")


# --------------------------------------------------------------------------
# Alerts
# --------------------------------------------------------------------------

def send_alert(cfg: dict, text: str) -> bool:
    sent = False
    a = cfg.get("alerts", {})
    tg = a.get("telegram") or {}
    if tg.get("enabled"):
        tok, chat = env(tg.get("bot_token_env")), env(tg.get("chat_id_env"))
        if tok and chat:
            try:
                r = requests.post(
                    f"https://api.telegram.org/bot{tok}/sendMessage",
                    json={"chat_id": chat, "text": text, "disable_web_page_preview": True},
                    timeout=HTTP_TIMEOUT,
                )
                sent = sent or r.ok
                if not r.ok:
                    log.error("telegram: HTTP %s %s", r.status_code, r.text[:200])
            except Exception as e:
                log.error("telegram: %s", e)
        else:
            log.error("telegram enabled but token/chat id env vars are missing")
    wh = a.get("webhook") or {}
    if wh.get("enabled"):
        url = env(wh.get("url_env"))
        if url:
            try:
                r = requests.post(url, json={"text": text, "content": text, "source": "aimeter"}, timeout=HTTP_TIMEOUT)
                sent = sent or r.ok
            except Exception as e:
                log.error("webhook: %s", e)
    if not sent:
        log.warning("ALERT (not delivered): %s", text)
    return sent


def alert_once(con, cfg: dict, key: str, text: str) -> None:
    if con.execute("SELECT 1 FROM alerts_sent WHERE key=?", (key,)).fetchone():
        return
    log.info("alert: %s", text)
    send_alert(cfg, text)
    con.execute("INSERT OR REPLACE INTO alerts_sent(key, ts, message) VALUES (?,?,?)", (key, iso(now_utc()), text))
    con.commit()


def crossed(used_pct: float, thresholds: list) -> float | None:
    hit = [t for t in sorted(thresholds) if used_pct >= t]
    return hit[-1] if hit else None


def run_checks(con, cfg: dict) -> None:
    s = cfg["settings"]
    th = s["alert_thresholds"]
    now = now_utc()
    month = now.strftime("%Y-%m")
    today = dt.date.today()

    for acct in cfg["api_accounts"]:
        aid, label = acct["id"], acct.get("label", acct["id"])
        snap = latest_snapshot(con, aid)
        if not snap:
            continue
        if not snap["ok"]:
            if snap["error"].startswith("NOT_CONNECTED"):
                if kv_get(con, f"oauth:{aid}"):  # was connected before, so the login expired
                    alert_once(con, cfg, f"{aid}:disconnected:{today}",
                               f"🔌 {label}: login expired, open the dashboard and click Reconnect")
                continue
            alert_once(con, cfg, f"{aid}:error:{today}", f"⚠️ {label}: collector failed\n{snap['error'][:300]}")
            continue
        m = snap["metrics"]
        for w in m.get("windows") or []:
            # plan windows (5-hour, weekly...). Budget/cap have their own alerts below,
            # per-minute API buckets reset too fast to be worth a message.
            if w["key"] in ("budget", "daily", "cap") or (w.get("window_seconds") or 0) <= 60:
                continue
            if w.get("used_pct") is None:
                continue
            t = crossed(w["used_pct"] / 100.0, th)
            if t is not None:
                when = ""
                if w.get("resets_at"):
                    left = dt.datetime.fromisoformat(w["resets_at"].replace("Z", "+00:00")) - now
                    secs = max(0, int(left.total_seconds()))
                    d_, h_, m_ = secs // 86400, secs % 86400 // 3600, secs % 3600 // 60
                    when = f", resets in {d_}d {h_}h" if d_ else f", resets in {h_}h {m_}m"
                alert_once(con, cfg, f"{aid}:win:{w['key']}:{t}:{(w.get('resets_at') or month)[:13]}",
                           f"⏳ {label}: {w['label']} at {w['used_pct']:.0f}%{when}")
        budget = acct.get("monthly_budget")
        if budget and m.get("spend_mtd") is not None:
            pct = m["spend_mtd"] / float(budget)
            t = crossed(pct, th)
            if t is not None:
                alert_once(con, cfg, f"{aid}:budget:{t}:{month}",
                           f"💸 {label}: ${m['spend_mtd']:.2f} of ${budget} monthly budget ({pct:.0%})")
        if m.get("cap") and m.get("cap_remaining") is not None:
            pct = 1 - float(m["cap_remaining"]) / float(m["cap"])
            t = crossed(pct, th)
            if t is not None:
                alert_once(con, cfg, f"{aid}:cap:{t}:{month}",
                           f"🧢 {label}: key cap {pct:.0%} used (${m['cap_remaining']:.2f} of ${m['cap']} left)")
        low = acct.get("low_balance")
        if low is not None and m.get("balance") is not None and m["balance"] < float(low):
            alert_once(con, cfg, f"{aid}:lowbal:{today}",
                       f"🪫 {label}: balance {m['balance']:.2f} {m.get('balance_currency', 'USD')} is below {low}")
        daily_budget = acct.get("daily_budget")
        if daily_budget and m.get("spend_today", 0) >= float(daily_budget):
            alert_once(con, cfg, f"{aid}:daily:{today}",
                       f"📈 {label}: ${m['spend_today']:.2f} spent today (daily limit ${daily_budget})")

    for sub in cfg["subscriptions"]:
        sid, name = sub["id"], sub.get("name", sub["id"])
        nr = next_renewal(sub, today)
        if nr:
            days = (nr - today).days
            for d in s["renewal_reminder_days"]:
                if days == d or (d == min(s["renewal_reminder_days"]) and 0 <= days <= d):
                    cost = f"{sub.get('cost')} {sub.get('currency', 'USD')}" if sub.get("cost") is not None else ""
                    alert_once(con, cfg, f"{sid}:renew:{nr}:{d}",
                               f"🔁 {name} renews in {days} day(s) on {nr} {cost}".strip())
                    break
        mu = latest_manual(con, sid)
        if mu:
            lim = mu["lim"] or sub.get("usage_limit")
            pct = (mu["value"] / 100.0) if mu["unit"] == "%" else (mu["value"] / float(lim) if lim else None)
            if pct is not None:
                t = crossed(pct, th)
                if t is not None:
                    period = usage_period_key(sub, dt.datetime.fromisoformat(mu["ts"].replace("Z", "+00:00")))
                    alert_once(con, cfg, f"{sid}:manual:{t}:{period}",
                               f"📊 {name}: {pct:.0%} of {sub.get('limit_period', 'monthly')} limit used")


# --------------------------------------------------------------------------
# Commands
# --------------------------------------------------------------------------

def cmd_collect(cfg, args) -> int:
    con = db_connect(cfg)
    failures = 0
    force = getattr(args, "force", False) or bool(args.only)
    for acct in cfg["api_accounts"]:
        if args.only and acct["id"] not in args.only:
            continue
        prov = acct.get("provider", "manual")
        fn = COLLECTORS.get(prov)
        ts = iso(now_utc())
        if not fn:
            log.error("%s: unknown provider %r", acct["id"], prov)
            continue
        if not force:
            last = latest_snapshot(con, acct["id"])
            every = int(acct.get("interval") or DEFAULT_INTERVAL.get(prov, 1800))
            if last:
                age = (now_utc() - dt.datetime.fromisoformat(last["ts"].replace("Z", "+00:00"))).total_seconds()
                if age < every - 5:
                    continue
        try:
            m = fn(acct, con)
            con.execute("INSERT INTO snapshots(ts, account_id, ok, metrics) VALUES (?,?,1,?)",
                        (ts, acct["id"], json.dumps(m)))
            log.info("%s: ok %s", acct["id"], {k: m[k] for k in ("spend_mtd", "balance", "cap_remaining") if k in m}
                     or [f"{w['label']} {w['used_pct']}%" for w in m.get("windows", [])])
        except NotConnected as e:
            con.execute("INSERT INTO snapshots(ts, account_id, ok, error) VALUES (?,?,0,?)",
                        (ts, acct["id"], f"NOT_CONNECTED: {e}"))
            log.info("%s: %s", acct["id"], e)
        except Exception as e:
            failures += 1
            con.execute("INSERT INTO snapshots(ts, account_id, ok, error) VALUES (?,?,0,?)",
                        (ts, acct["id"], str(e)))
            log.error("%s: %s", acct["id"], e)
        con.commit()
    # keep the DB small: one snapshot per account per hour is plenty after 7 days
    con.execute("""DELETE FROM snapshots WHERE ts < ? AND id NOT IN (
                     SELECT MAX(id) FROM snapshots GROUP BY account_id, substr(ts,1,13))""",
                (iso(now_utc() - dt.timedelta(days=7)),))
    con.commit()
    if not args.no_alerts:
        run_checks(con, cfg)
    return 1 if failures and args.strict else 0


def cmd_log(cfg, args) -> int:
    ids = {s["id"] for s in cfg["subscriptions"]} | {a["id"] for a in cfg["api_accounts"]}
    if args.id not in ids:
        print(f"Unknown id {args.id!r}. Known: {', '.join(sorted(ids))}")
        return 2
    con = db_connect(cfg)
    con.execute("INSERT INTO manual_usage(ts, sub_id, value, unit, lim, note) VALUES (?,?,?,?,?,?)",
                (iso(now_utc()), args.id, args.value, args.unit, args.limit, args.note))
    con.commit()
    print(f"Logged {args.value}{args.unit or ''} for {args.id}")
    run_checks(con, cfg)
    return 0


# Which Hermes billing providers / model names belong to each widget (substring match,
# case-insensitive). Override per account with `hermes_match: [...]`.
HERMES_MATCH = {
    "claude_sub": ["anthropic", "claude"], "anthropic": ["anthropic", "claude"], "anthropic_limits": ["anthropic", "claude"],
    "codex_sub": ["codex", "chatgpt"], "openai": ["openai"], "openai_limits": ["openai"],
    "kimi_code": ["kimi", "moonshot"], "kimi_api": ["moonshot", "kimi"], "opencode_go": ["opencode"],
    "nous": ["nous", "hermes"], "deepseek": ["deepseek"], "openrouter": ["openrouter"],
}


def _hermes_usage_since(hourly, keys, start: dt.datetime):
    lo = start.astimezone(UTC).strftime("%Y-%m-%dT%H")
    tok = cost = 0
    hit = False
    for hr, provider, model, t, c in hourly:
        if hr < lo:
            continue
        hay = f"{provider} {model if not provider else ''}".lower()
        if any(k in hay for k in keys):
            tok += t
            cost += c
            hit = True
    return (tok, round(cost, 4)) if hit else (0, 0.0)


def enrich_windows(cfg, apis):
    """Attach tokens + cost used inside each window, so every % has tokens and $ beside it."""
    hermes = next((a for a in apis if a["provider"] == "hermes" and a["metrics"].get("hourly") is not None), None)
    hourly = hermes["metrics"]["hourly"] if hermes else []
    now = now_utc()
    for a in apis:
        acct = next((x for x in cfg["api_accounts"] if x["id"] == a["id"]), {})
        keys = [k.lower() for k in (acct.get("hermes_match") or HERMES_MATCH.get(a["provider"], []))]
        tu = a["metrics"].get("token_usage")
        for w in a["metrics"].get("windows") or []:
            if w["key"] == "budget" and tu:
                w["tokens"], w["cost"], w["tokens_src"] = tu["totals"]["input"] + tu["totals"]["output"] + tu["totals"]["cache"], tu["totals"]["cost"], "provider"
                continue
            if w["key"] == "daily" and tu:
                t = tu["today"]
                w["tokens"], w["cost"], w["tokens_src"] = t["input"] + t["output"] + t["cache"], t["cost"], "provider"
                continue
            if not hourly or not keys or (w.get("window_seconds") or 0) <= 60:
                continue
            if w.get("resets_at") and w.get("window_seconds"):
                start = dt.datetime.fromisoformat(w["resets_at"].replace("Z", "+00:00")) - dt.timedelta(seconds=w["window_seconds"])
            elif w["key"] in ("budget", "cap"):
                start = month_start(now)
            elif w["key"] == "daily":
                start = now.replace(hour=0, minute=0, second=0, microsecond=0)
            else:
                continue
            w["tokens"], w["cost"] = _hermes_usage_since(hourly, keys, start)
            w["tokens_src"] = "hermes"
        # token limits: exact if configured (token_limits: {five_hour: 2000000}), else estimated
        exact = acct.get("token_limits") or {}
        for w in a["metrics"].get("windows") or []:
            if w.get("unit") in ("tokens", "USD") or w["key"] in ("budget", "daily", "cap"):
                continue
            if exact.get(w["key"]):
                w["token_limit"], w["token_limit_est"] = int(exact[w["key"]]), False
            elif w.get("tokens") and (w.get("used_pct") or 0) >= 3:
                w["token_limit"], w["token_limit_est"] = int(w["tokens"] / (w["used_pct"] / 100)), True
        # your own token budgets: token_budgets: {daily: 2000000, weekly: 10000000, monthly: ...}
        tb = acct.get("token_budgets") or {}
        day0 = now.replace(hour=0, minute=0, second=0, microsecond=0)
        periods = {"daily": (day0, day0 + dt.timedelta(days=1), 86400, "Daily tokens"),
                   "weekly": (day0 - dt.timedelta(days=now.weekday()), day0 + dt.timedelta(days=7 - now.weekday()), 604800, "Weekly tokens"),
                   "monthly": (month_start(now), next_month_start(now), None, "Monthly tokens")}
        for per, (start, reset, secs, label) in periods.items():
            lim = tb.get(per)
            if not lim:
                continue
            if tu:
                d0 = start.strftime("%Y-%m-%d")
                rows = [d for d in tu["daily"] if d["date"] >= d0]
                used, cost = sum(d["tokens"] for d in rows), round(sum(d["cost"] for d in rows), 4)
            elif hourly and keys:
                used, cost = _hermes_usage_since(hourly, keys, start)
            else:
                continue
            w = window(f"tok_{per}", label, used / float(lim) * 100, resets_at=reset, window_seconds=secs,
                       limit=int(lim), remaining=int(lim) - used, unit="tokens")
            w["tokens"], w["cost"], w["tokens_src"] = used, cost, "provider" if tu else "hermes"
            a["metrics"].setdefault("windows", []).append(w)
        # month / today token totals for widgets without their own token report
        if not tu and hourly and keys and a["provider"] != "hermes":
            mt, mc = _hermes_usage_since(hourly, keys, month_start(now))
            dtk, dc = _hermes_usage_since(hourly, keys, now.replace(hour=0, minute=0, second=0, microsecond=0))
            if mt:
                a["metrics"]["hermes_tokens"] = {"month": mt, "month_cost": mc, "today": dtk, "today_cost": dc}
        a["metrics"].pop("hourly", None) if a["provider"] == "hermes" else None


PRETTY = {"nous": "Nous Portal", "kimi-coding": "Kimi Code", "kimi": "Kimi", "moonshot": "Kimi API (Moonshot)",
          "opencode-go": "OpenCode Go", "opencode": "OpenCode", "deepseek": "DeepSeek", "openrouter": "OpenRouter",
          "anthropic": "Anthropic", "openai": "OpenAI", "openai-codex": "ChatGPT / Codex", "gemini": "Google Gemini",
          "google": "Google Gemini", "unknown": "Unknown provider"}


def token_total(apis) -> dict | None:
    """One deduplicated total across every source. Each provider is counted once, using
    whichever source saw more of it (a provider's own report also includes Hermes's calls)."""
    hermes = next((a for a in apis if a["provider"] == "hermes" and a["metrics"].get("hourly")), None)
    own = {a["provider"]: a for a in apis if a["provider"] in ("anthropic", "openai", "openrouter")
           and a["metrics"].get("token_usage")}
    if not hermes and not own:
        return None
    now = now_utc()
    month, today = now.strftime("%Y-%m"), now.strftime("%Y-%m-%d")
    groups = {}

    def g(name, label):
        return groups.setdefault(name, {"name": label, "own": None, "hermes": {"month": 0, "month_cost": 0.0,
                                         "today": 0, "today_cost": 0.0, "daily": {}}})
    for prov, a in own.items():
        tu = a["metrics"]["token_usage"]
        t, d = tu["totals"], tu["today"]
        g(prov, a["label"])["own"] = {
            "month": t["input"] + t["output"] + t["cache"], "month_cost": t["cost"] or 0.0,
            "today": d["input"] + d["output"] + d["cache"], "today_cost": d["cost"] or 0.0,
            "daily": {x["date"]: (x["tokens"], x["cost"] or 0.0) for x in tu["daily"]}, "label": a["label"]}
    if hermes:
        for hr, provider, model, tok, cost in hermes["metrics"]["hourly"]:
            hay = f"{provider} {model if not provider else ''}".lower()
            key = next((p for p in own if any(k in hay for k in HERMES_MATCH.get(p, [p]))), None) or (provider or "unknown")
            grp = g(key, own[key]["label"] if key in own else PRETTY.get(key.lower(), key))
            h, day = grp["hermes"], hr[:10]
            dd = h["daily"].setdefault(day, [0, 0.0])
            dd[0] += tok
            dd[1] += cost
            if day.startswith(month):
                h["month"] += tok
                h["month_cost"] += cost
            if day == today:
                h["today"] += tok
                h["today_cost"] += cost
    rows, daily = [], {}
    tot = {"tokens": 0, "cost": 0.0, "today": 0, "today_cost": 0.0}
    for key, grp in groups.items():
        o, h = grp["own"], grp["hermes"]
        use_own = o is not None and o["month"] >= h["month"]
        src = o if use_own else h
        rows.append({"name": grp["name"], "tokens": int(src["month"]), "cost": round(src["month_cost"], 4),
                     "today": int(src["today"]), "today_cost": round(src["today_cost"], 4),
                     "from": o["label"] + " report" if use_own else "Hermes sessions"})
        tot["tokens"] += src["month"]
        tot["cost"] += src["month_cost"]
        tot["today"] += src["today"]
        tot["today_cost"] += src["today_cost"]
        for day in set(h["daily"]) | set((o or {}).get("daily", {})):
            ht, hc = h["daily"].get(day, (0, 0.0))
            ot, oc = (o or {}).get("daily", {}).get(day, (0, 0.0))
            dt_ = daily.setdefault(day, [0, 0.0])
            dt_[0] += max(ht, ot)
            dt_[1] += max(hc, oc)
    rows.sort(key=lambda r: -r["tokens"])
    return {"tokens": int(tot["tokens"]), "cost": round(tot["cost"], 4), "today": int(tot["today"]),
            "today_cost": round(tot["today_cost"], 4), "by_provider": rows,
            "daily": [{"date": d, "tokens": int(v[0]), "cost": round(v[1], 4)} for d, v in sorted(daily.items())][-31:]}


# Providers that can be connected from the dashboard. "fields" are asked for in the form;
# secret fields are stored in the server's database and never sent back to the browser.
CATALOG = {
    "claude_sub":       {"name": "Claude plan", "group": "Plans", "blurb": "5-hour and weekly limits of a Claude Pro or Max plan.", "signin": True, "fields": []},
    "codex_sub":        {"name": "ChatGPT / Codex plan", "group": "Plans", "blurb": "5-hour and weekly Codex limits of a ChatGPT plan.", "signin": True, "fields": []},
    "kimi_code":        {"name": "Kimi Code", "group": "Plans", "blurb": "5-hour window and plan quota.", "fields": [["api_key", "Kimi Code API key", True]]},
    "opencode_go":      {"name": "OpenCode Go", "group": "Plans", "blurb": "Rolling 5-hour, weekly and monthly allowance.", "fields": [["api_key", "OpenCode Go API key", True]]},
    "openrouter":       {"name": "OpenRouter", "group": "API credits", "blurb": "Spend, key cap, credits. Add a management key for tokens per model.",
                         "fields": [["api_key", "API key", True], ["management_key", "Management key (optional)", True], ["monthly_budget", "Monthly budget in USD (optional)", False]]},
    "deepseek":         {"name": "DeepSeek", "group": "API credits", "blurb": "Prepaid balance.", "fields": [["api_key", "API key", True], ["low_balance", "Alert below this balance (optional)", False]]},
    "kimi_api":         {"name": "Kimi API (Moonshot)", "group": "API credits", "blurb": "Prepaid balance on the Kimi Open Platform.", "fields": [["api_key", "API key", True], ["low_balance", "Alert below this balance (optional)", False]]},
    "anthropic":        {"name": "Anthropic API spend", "group": "API credits", "blurb": "Monthly spend and tokens per model. Needs an admin key (sk-ant-admin...).",
                         "fields": [["api_key", "Admin key", True], ["monthly_budget", "Monthly budget in USD (optional)", False]]},
    "openai":           {"name": "OpenAI API spend", "group": "API credits", "blurb": "Monthly spend and tokens per model. Needs an admin key.",
                         "fields": [["api_key", "Admin key", True], ["monthly_budget", "Monthly budget in USD (optional)", False]]},
    "anthropic_limits": {"name": "Anthropic rate limits", "group": "Rate limits", "blurb": "Tokens and requests per minute. One 1-token request per check.",
                         "fields": [["api_key", "API key", True], ["probe_model", "Model to check with", False, "claude-haiku-5-5"]]},
    "openai_limits":    {"name": "OpenAI rate limits", "group": "Rate limits", "blurb": "Tokens and requests per minute. One 1-token request per check.",
                         "fields": [["api_key", "API key", True], ["probe_model", "Model to check with", False, "gpt-5-nano"]]},
    "nous":             {"name": "Nous Portal", "group": "Rate limits", "blurb": "Rate limits, when Nous reports them. Credits are only shown in the Portal.",
                         "fields": [["api_key", "API key", True], ["probe_model", "Model to check with", False, "Hermes-4-70B"]]},
    "hermes":           {"name": "Hermes Agent", "group": "Usage records", "blurb": "Tokens and cost of everything Hermes runs, from its own records. No key needed.",
                         "fields": [["state_db", "Path to state.db", False, "/hermes/state.db"]]},
    "manual":           {"name": "Other service", "group": "Usage records", "blurb": "Anything without an API. You add readings by hand.", "fields": [["usage_url", "Usage page link (optional)", False]]},
}
SECRET_FIELDS = {"api_key": "api_key_env", "management_key": "management_key_env"}


def merge_db_accounts(cfg, con=None) -> None:
    """Add the providers connected from the dashboard to cfg["api_accounts"]."""
    con = con or db_connect(cfg)
    known = {a["id"] for a in cfg["api_accounts"]}
    for acct in kv_get(con, "ui_accounts") or []:
        if acct["id"] in known:
            continue
        acct = dict(acct, _ui=True)
        for field, env_field in SECRET_FIELDS.items():
            val = kv_get(con, f"secret:{acct['id']}:{field}")
            if val:
                name = f"AIMETER_SECRET_{re.sub(r'[^A-Z0-9]', '_', acct['id'].upper())}_{field.upper()}"
                os.environ[name] = val
                acct[env_field] = name
        cfg["api_accounts"].append(acct)


def add_ui_account(cfg, con, body: dict) -> dict:
    prov = body.get("provider")
    if prov not in CATALOG:
        raise RuntimeError("Unknown provider.")
    meta = CATALOG[prov]
    label = (body.get("label") or meta["name"]).strip()[:60]
    base = re.sub(r"[^a-z0-9]+", "-", label.lower()).strip("-") or prov
    ids = {a["id"] for a in cfg["api_accounts"]}
    aid, n = base, 2
    while aid in ids:
        aid, n = f"{base}-{n}", n + 1
    acct = {"id": aid, "label": label, "provider": prov}
    for f in meta["fields"]:
        key, secret = f[0], f[2]
        val = str(body.get(key) or "").strip()
        if not val:
            if secret and key == "api_key":
                raise RuntimeError("Paste the API key first.")
            if len(f) > 3:
                acct[key] = f[3]
            continue
        if secret:
            kv_set(con, f"secret:{aid}:{key}", val)
        elif key in ("monthly_budget", "low_balance"):
            try:
                acct[key] = float(val)
            except ValueError:
                raise RuntimeError(f"{f[1]} must be a number.")
        else:
            acct[key] = val
    if body.get("plan"):
        acct["plan"] = str(body["plan"])[:40]
    saved = kv_get(con, "ui_accounts") or []
    saved.append(acct)
    kv_set(con, "ui_accounts", saved)
    merge_db_accounts(cfg, con)
    return acct


def remove_ui_account(cfg, con, aid: str) -> None:
    saved = [a for a in (kv_get(con, "ui_accounts") or []) if a["id"] != aid]
    kv_set(con, "ui_accounts", saved)
    for field in SECRET_FIELDS:
        kv_set(con, f"secret:{aid}:{field}", None)
    kv_set(con, f"oauth:{aid}", None)
    con.execute("DELETE FROM snapshots WHERE account_id=?", (aid,))
    con.commit()
    cfg["api_accounts"][:] = [a for a in cfg["api_accounts"] if a["id"] != aid]


def build_state(cfg) -> dict:
    con = db_connect(cfg)
    fx = cfg["settings"]["fx_to_usd"]
    today = dt.date.today()
    apis = []
    since = iso(now_utc() - dt.timedelta(hours=24))
    for a in cfg["api_accounts"]:
        prov = a.get("provider", "manual")
        snap = latest_snapshot(con, a["id"])
        good = snap if snap and snap["ok"] else latest_snapshot(con, a["id"], ok_only=True)
        mu = latest_manual(con, a["id"])
        err = snap["error"] if snap and not snap["ok"] else None
        # 24h history of each window's used % (for the sparklines), max ~96 points
        hist = {}
        rows = con.execute("SELECT ts, metrics FROM snapshots WHERE account_id=? AND ok=1 AND ts>=? ORDER BY ts",
                           (a["id"], since)).fetchall()
        step = max(1, len(rows) // 96)
        for r in rows[::step]:
            for w in (json.loads(r["metrics"]).get("windows") or []):
                if w.get("used_pct") is not None:
                    hist.setdefault(w["key"], []).append([r["ts"], w["used_pct"]])
        oauth = kv_get(con, f"oauth:{a['id']}") if prov in OAUTH else None
        name, kind = PROVIDER_META.get(prov, (prov, "spend"))
        apis.append({
            "id": a["id"], "label": a.get("label", a["id"]), "provider": prov, "provider_name": name, "kind": kind,
            "removable": bool(a.get("_ui")),
            "budget": a.get("monthly_budget"), "console_url": a.get("console_url") or a.get("usage_url"),
            "notes": a.get("notes"), "plan": a.get("plan"), "low_balance": a.get("low_balance"),
            "interval": int(a.get("interval") or DEFAULT_INTERVAL.get(prov, 1800)),
            "metrics": good["metrics"] if good else {},
            "updated": good["ts"] if good else None,
            "checked": snap["ts"] if snap else None,
            "error": err.replace("NOT_CONNECTED: ", "") if err else None,
            "not_connected": bool(err and err.startswith("NOT_CONNECTED")),
            "oauth": prov in OAUTH, "connected": bool(oauth) if prov in OAUTH else None,
            "account": (oauth or {}).get("email"),
            "history": hist,
            "manual": mu,
        })
    subs = []
    for sb in cfg["subscriptions"]:
        nr = next_renewal(sb, today)
        mu = latest_manual(con, sb["id"])
        if mu and not mu["lim"] and mu["unit"] != "%":
            mu["lim"] = sb.get("usage_limit")
        subs.append({
            "id": sb["id"], "name": sb.get("name", sb["id"]), "vendor": sb.get("vendor", ""),
            "category": sb.get("category", "other"), "plan": sb.get("plan", ""),
            "cost": sb.get("cost"), "currency": sb.get("currency", "USD"),
            "cycle": sb.get("cycle", "monthly"),
            "monthly_usd": monthly_cost_usd(sb, fx),
            "next_renewal": nr.isoformat() if nr else None,
            "days_left": (nr - today).days if nr else None,
            "limits": sb.get("limits", ""), "usage_url": sb.get("usage_url"),
            "limit_period": sb.get("limit_period"),
            "manual": mu,
        })
    total = token_total(apis)
    enrich_windows(cfg, apis)
    token_sources = [{"id": x["id"], "label": x["label"], "provider": x["provider"],
                      "usage": x["metrics"]["token_usage"], "updated": x["updated"]}
                     for x in apis if x["metrics"].get("token_usage")]
    token_sources.sort(key=lambda t: (t["provider"] != "hermes", -(t["usage"]["totals"].get("input", 0) + t["usage"]["totals"].get("output", 0))))
    api_mtd = sum((x["metrics"].get("spend_mtd") or 0) for x in apis if x["provider"] != "hermes")
    fixed = sum((x["monthly_usd"] or 0) for x in subs)
    recent = [dict(r) for r in con.execute("SELECT * FROM alerts_sent ORDER BY ts DESC LIMIT 15")]
    return {
        "generated": iso(now_utc()), "apis": apis, "subscriptions": subs, "token_sources": token_sources,
        "token_total": total,
        "catalog": {k: {"name": v["name"], "group": v["group"], "blurb": v["blurb"], "signin": v.get("signin", False),
                        "fields": [{"key": f[0], "label": f[1], "secret": f[2], "default": f[3] if len(f) > 3 else ""} for f in v["fields"]]}
                    for k, v in CATALOG.items()},
        "totals": {"api_mtd_usd": round(api_mtd, 2), "subscriptions_monthly_usd": round(fixed, 2),
                   "all_usd": round(api_mtd + fixed, 2)},
        "alerts": recent,
    }


def cmd_status(cfg, args) -> int:
    st = build_state(cfg)
    if args.json:
        print(json.dumps(st, indent=2))
        return 0
    print(f"\nAPI ACCOUNTS (month to date, generated {st['generated']})")
    for a in st["apis"]:
        m = a["metrics"]
        parts = []
        if "spend_mtd" in m:
            parts.append(f"${m['spend_mtd']:.2f}" + (f" / ${a['budget']}" if a["budget"] else ""))
        if m.get("balance") is not None:
            parts.append(f"balance {m['balance']:.2f}")
        if m.get("cap"):
            parts.append(f"cap left {m.get('cap_remaining')}/{m['cap']}")
        if a["error"]:
            parts.append(f"ERROR: {a['error'][:80]}")
        print(f"  {a['label']:<28} {'  '.join(parts) or '(no data yet)'}")
    print("\nSUBSCRIPTIONS")
    for s in sorted(st["subscriptions"], key=lambda x: (x["days_left"] is None, x["days_left"] or 0)):
        cost = f"{s['cost']} {s['currency']}/{s['cycle']}" if s["cost"] is not None else ""
        ren = f"renews {s['next_renewal']} ({s['days_left']}d)" if s["next_renewal"] else ""
        mu = s["manual"]
        use = f"  usage {mu['value']}{mu['unit'] or ''}" if mu else ""
        print(f"  {s['name']:<28} {cost:<22} {ren}{use}")
    t = st["totals"]
    print(f"\nTOTAL  API this month ${t['api_mtd_usd']}  +  subscriptions ${t['subscriptions_monthly_usd']}/mo"
          f"  =  ${t['all_usd']}\n")
    return 0


def cmd_test_alert(cfg, args) -> int:
    ok = send_alert(cfg, "✅ AI Meter test alert: your usage monitor can reach you.")
    print("sent" if ok else "not sent (check alerts config and env vars)")
    return 0 if ok else 1


# --------------------------------------------------------------------------
# Dashboard
# --------------------------------------------------------------------------

def cmd_serve(cfg, args) -> int:
    d = cfg["settings"]["dashboard"]
    host = args.host or d.get("host", "127.0.0.1")
    port = args.port or int(d.get("port", 8787))
    token = env(d.get("token_env"))
    page = (HERE / "dashboard.html").read_text()

    class H(BaseHTTPRequestHandler):
        def log_message(self, fmt, *a):
            log.debug(fmt, *a)

        def _authed(self) -> bool:
            if not token:
                return True
            q = parse_qs(urlparse(self.path).query).get("token", [""])[0]
            if q and hmac.compare_digest(q, token):
                return True
            auth = self.headers.get("Authorization", "")
            if auth.startswith("Basic "):
                try:
                    pw = base64.b64decode(auth[6:]).decode().split(":", 1)[1]
                    return hmac.compare_digest(pw, token)
                except Exception:
                    return False
            if auth.startswith("Bearer "):
                return hmac.compare_digest(auth[7:], token)
            return False

        def _send(self, code, body: bytes, ctype):
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            path = urlparse(self.path).path
            if path == "/healthz":
                return self._send(200, b"ok", "text/plain")
            if not self._authed():
                self.send_response(401)
                self.send_header("WWW-Authenticate", 'Basic realm="AI Meter"')
                self.end_headers()
                return
            if path == "/api/state":
                return self._send(200, json.dumps(build_state(cfg)).encode(), "application/json")
            if path in ("/", "/index.html"):
                return self._send(200, page.encode(), "text/html; charset=utf-8")
            self._send(404, b"not found", "text/plain")

        def do_POST(self):
            if not self._authed():
                return self._send(401, b"unauthorized", "text/plain")
            path = urlparse(self.path).path
            n = int(self.headers.get("Content-Length") or 0)
            try:
                body = json.loads(self.rfile.read(n) or b"{}")
            except ValueError:
                return self._send(400, b"bad json", "text/plain")
            if path == "/api/log":
                ns = argparse.Namespace(id=str(body.get("id", "")), value=float(body.get("value", 0)),
                                        unit=body.get("unit") or None, limit=body.get("limit"),
                                        note=body.get("note"))
                rc = cmd_log(cfg, ns)
                return self._send(200 if rc == 0 else 400, json.dumps({"ok": rc == 0}).encode(), "application/json")
            if path == "/api/collect":
                only = body.get("only") or None
                cmd_collect(cfg, argparse.Namespace(only=only, no_alerts=False, strict=False, force=True))
                return self._send(200, b'{"ok":true}', "application/json")
            if path in ("/api/providers/add", "/api/providers/remove"):
                con = db_connect(cfg)
                try:
                    if path.endswith("add"):
                        acct = add_ui_account(cfg, con, body)
                        if acct["provider"] in OAUTH:
                            return self._send(200, json.dumps({"ok": True, "id": acct["id"], "signin": True}).encode(), "application/json")
                        cmd_collect(cfg, argparse.Namespace(only=[acct["id"]], no_alerts=True, strict=False, force=True))
                        snap = latest_snapshot(con, acct["id"])
                        res = {"ok": True, "id": acct["id"], "checked": bool(snap and snap["ok"]),
                               "error": (snap or {}).get("error")}
                    else:
                        acct = next((a for a in cfg["api_accounts"] if a["id"] == body.get("id")), None)
                        if not acct or not acct.get("_ui"):
                            raise RuntimeError("Only providers connected from this page can be removed here. Edit config.yaml for the others.")
                        remove_ui_account(cfg, con, acct["id"])
                        res = {"ok": True}
                except Exception as e:
                    return self._send(400, json.dumps({"error": str(e)[:300]}).encode(), "application/json")
                return self._send(200, json.dumps(res).encode(), "application/json")
            if path.startswith("/api/oauth/"):
                acct = next((a for a in cfg["api_accounts"] if a["id"] == body.get("id")), None)
                if not acct or acct.get("provider") not in OAUTH:
                    return self._send(400, b'{"error":"unknown account"}', "application/json")
                con = db_connect(cfg)
                try:
                    if path == "/api/oauth/start":
                        res = oauth_start(con, acct)
                    elif path == "/api/oauth/finish":
                        rec = oauth_finish(con, acct, str(body.get("code", "")))
                        cmd_collect(cfg, argparse.Namespace(only=[acct["id"]], no_alerts=True, strict=False, force=True))
                        res = {"ok": True, "account": rec.get("email")}
                    elif path == "/api/oauth/disconnect":
                        kv_set(con, f"oauth:{acct['id']}", None)
                        res = {"ok": True}
                    else:
                        return self._send(404, b"not found", "text/plain")
                except Exception as e:
                    return self._send(400, json.dumps({"error": str(e)[:300]}).encode(), "application/json")
                return self._send(200, json.dumps(res).encode(), "application/json")
            self._send(404, b"not found", "text/plain")

    if host not in ("127.0.0.1", "localhost") and not token:
        log.warning("Dashboard is listening on %s without a token. Set settings.dashboard.token_env.", host)
    log.info("dashboard on http://%s:%s", host, port)
    if not getattr(args, "no_collect", False):
        import threading
        import time as _time

        def loop():
            while True:
                try:
                    c = load_config(args.config)
                    merge_db_accounts(c)
                    cmd_collect(c, argparse.Namespace(only=None, no_alerts=False, strict=False, force=False))
                except Exception as e:  # keep the loop alive
                    log.error("collector loop: %s", e)
                _time.sleep(60)
        threading.Thread(target=loop, daemon=True, name="aimeter-collector").start()
        log.info("background checks every 60 s (each provider on its own interval)")
    print(f"\n  AI Meter is running: http://{'localhost' if host in ('127.0.0.1', '0.0.0.0') else host}:{port}\n"
          f"  config: {getattr(args, 'config', None) or default_config_path()}\n", flush=True)
    ThreadingHTTPServer((host, port), H).serve_forever()
    return 0


def main(argv=None) -> int:
    p = argparse.ArgumentParser(prog="aimeter", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("-c", "--config", help="path to config.yaml (default: ~/.aimeter/config.yaml)")
    p.add_argument("-v", "--verbose", action="store_true")
    sp = p.add_subparsers(dest="cmd")

    c = sp.add_parser("collect", help="poll APIs, store snapshot, send alerts")
    c.add_argument("--only", nargs="*", help="only these account ids")
    c.add_argument("--no-alerts", action="store_true")
    c.add_argument("--strict", action="store_true", help="exit 1 if any collector fails")
    c.add_argument("--force", action="store_true", help="ignore per-account intervals and poll everything now")

    s = sp.add_parser("serve", help="run the dashboard and the background checks")
    s.add_argument("--host")
    s.add_argument("--port", type=int)
    s.add_argument("--no-collect", action="store_true", help="dashboard only; run checks elsewhere")

    st = sp.add_parser("status", help="terminal summary")
    st.add_argument("--json", action="store_true")

    lg = sp.add_parser("log", help="record a manual usage reading")
    lg.add_argument("id")
    lg.add_argument("value", type=float)
    lg.add_argument("--unit", help='e.g. "%" for percent of limit, "msgs", "credits"')
    lg.add_argument("--limit", type=float, help="the limit the value is measured against")
    lg.add_argument("--note")

    sp.add_parser("test-alert", help="send a test alert")

    args = p.parse_args(argv)
    if not args.cmd:  # plain `aimeter` = start the dashboard
        args = p.parse_args(list(argv or sys.argv[1:]) + ["serve"])
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.INFO,
                        format="%(asctime)s %(levelname)s %(message)s")
    cfg = load_config(args.config)
    merge_db_accounts(cfg)
    return {"collect": cmd_collect, "serve": cmd_serve, "status": cmd_status,
            "log": cmd_log, "test-alert": cmd_test_alert}[args.cmd](cfg, args)


if __name__ == "__main__":
    sys.exit(main())
