# aimon: AI subscription and usage monitor

A small self-hosted tool for your VPS. It keeps track of every AI account and subscription you pay for:

- **API accounts** (Anthropic, OpenAI, OpenRouter, DeepSeek): pulls month-to-date spend, today's spend, per-model cost, token counts, prepaid balance and key caps live from each provider's API every 30 minutes.
- **Chat subscriptions** (Claude, ChatGPT, Gemini) and **other SaaS** (Hostinger, Adobe, Magnific, n8n): tracks plan, cost, next renewal date and monthly cost in USD. You can log usage readings yourself (for example "Claude weekly limit 62%").
- **Alerts** go to Telegram or any webhook (n8n, Slack, Discord, Hermes) when spend crosses 50/80/95% of a budget, a key cap runs low, a balance drops, a collector fails or a renewal is 7/3/1 days away. Each alert is sent once per period, so you don't get repeats.
- **Dashboard** at `http://127.0.0.1:8787`, protected by a token.

## What can and cannot be tracked live

| Account type | Live data | How |
|---|---|---|
| Anthropic API | Spend, per-model cost, tokens | Admin API key (`sk-ant-admin...`), Usage and Cost API |
| OpenAI Platform | Spend, line items, tokens | Admin key (`sk-admin-...`), Organization Costs and Usage API |
| OpenRouter | Usage today/month/all time, key cap left, balance | Your normal API key, `GET /api/v1/key` |
| DeepSeek | Balance | `GET /user/balance` |
| Google AI Studio | None (no public spend API) | `provider: manual`, log readings |
| Claude / ChatGPT / Gemini plans | None (no usage API) | Renewal tracking + manual readings |
| Other SaaS | None | Renewal tracking + manual readings |

Admin keys are read-only for billing, but they can also manage your org. Create them only for this tool, and keep `.env` at `chmod 600`.

## Install on the VPS

```bash
scp -r ai-usage-monitor/ root@your-vps:/root/
ssh root@your-vps
cd /root/ai-usage-monitor
sudo bash deploy/install.sh
```

This creates a locked-down `aimon` system user, installs everything to `/opt/aimon`, and enables:

- `aimon-collect.timer`: runs a collection every 30 minutes
- `aimon-web.service`: the dashboard on `127.0.0.1:8787`

Then:

1. Edit `/opt/aimon/.env` with your keys, Telegram bot token, chat id and a dashboard token (`openssl rand -hex 24`).
2. Edit `/opt/aimon/config.yaml` with your real plans, prices, renewal dates and budgets. The example entries are placeholders.
3. Test:

```bash
cd /opt/aimon
sudo -u aimon .venv/bin/python aimon.py test-alert
sudo -u aimon .venv/bin/python aimon.py collect
sudo -u aimon .venv/bin/python aimon.py status
sudo systemctl restart aimon-web
```

## Open the dashboard

From your laptop, through an SSH tunnel:

```bash
ssh -L 8787:127.0.0.1:8787 root@your-vps
```

Then open `http://localhost:8787` and enter any username plus your dashboard token. To reach it from your phone, put it behind your existing reverse proxy (Caddy, Nginx) with HTTPS and keep the token set.

## Daily use

Log a reading for a plan that has no API:

```bash
aimon.py log claude 62 --unit % --note "weekly all-models"
aimon.py log n8n 1840                      # uses usage_limit from config
aimon.py log gemini-api 4.20 --note "MTD spend from Cloud Billing"
```

Or use the form at the bottom of the dashboard.

Other commands:

```bash
aimon.py status          # terminal summary
aimon.py status --json   # machine-readable, handy for a Hermes skill
aimon.py collect --only openrouter anthropic
```

## Adding an account

- Another API account of a supported provider: add an entry under `api_accounts` with a new `id` and its own `api_key_env`. You can list several OpenRouter keys or several Anthropic orgs.
- A new provider: write a `collect_<name>(acct)` function in `aimon.py` that returns the metrics dict described above it, and add it to `COLLECTORS`.
- A new subscription: add an entry under `subscriptions`. `renews_on` can be any past renewal date; it rolls forward automatically by `cycle`.

## Notes

- Month-to-date figures use the calendar month in UTC, which is how both Anthropic and OpenAI bill.
- Provider cost data can lag by a few hours.
- Snapshots older than 7 days are thinned to one per hour per account, so the database stays small.

## Run with Docker (Hostinger Docker Manager)

Deploy this repo as a Docker project (URL: `https://github.com/eslamelhefny/aimon`) and put your keys in the project environment, using `.env.example` as the list of variables. On first start the container writes `/opt/aimon/config.yaml` on the host: edit it with your real plans, then restart the project. The dashboard listens on `127.0.0.1:8787` (open it through an SSH tunnel).
