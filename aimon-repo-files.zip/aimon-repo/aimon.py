#!/usr/bin/env python3
"""
aimon: AI subscription and usage monitor.

Collects live spend, credits and caps from provider APIs, tracks renewal
dates and manual usage readings for chat subscriptions and other SaaS,
sends alerts (Telegram / webhook) and serves a small web dashboard.

Commands:
  collect            poll every API account, store a snapshot, send alerts
  serve              run the dashboard (default 127.0.0.1:8787)
  status             print a summary in the terminal
  log ID VALUE       record a manual usage reading for a subscription
  test-alert         send a test message to every enabled alert channel
"""
from __future__ import annotations

import argparse
import base64
import datetime as dt
import hmac
import json
import logging
import os
import sqlite3
import sys
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

import requests
import yaml

UTC = dt.timezone.utc
HERE = Path(__file__).resolve().parent
log = logging.getLogger("aimon")
HTTP_TIMEOUT = 30


# --------------------------------------------------------------------------
# Config
# --------------------------------------------------------------------------

def load_env_file(path: Path) -> None:
    """Minimal .env loader (KEY=VALUE lines). Existing env vars win."""
    if not path.exists():
        return
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        v = v.strip().strip('"').strip("'")
        os.environ.setdefault(k.strip(), v)


def load_config(path: str | None) -> dict:
    cfg_path = Path(path) if path else HERE / "config.yaml"
    load_env_file(cfg_path.parent / ".env")
    with open(cfg_path) as f:
        cfg = yaml.safe_load(f) or {}
    s = cfg.setdefault("settings", {})
    s.setdefault("db_path", "data/monitor.db")
    s.setdefault("alert_thresholds", [0.5, 0.8, 0.95])
    s.setdefault("renewal_reminder_days", [7, 3, 1])
    s.setdefault("fx_to_usd", {"USD": 1})
    s["fx_to_usd"].setdefault("USD", 1)
    s.setdefault("dashboard", {})
    db = Path(s["db_path"])
    s["db_path"] = str(db if db.is_absolute() else cfg_path.parent / db)
    cfg.setdefault("api_accounts", [])
    cfg.setdefault("subscriptions", [])
    cfg.setdefault("alerts", {})
    return cfg


def env(name: str | None) -> str | None:
    return os.environ.get(name) if name else None


# --------------------------------------------------------------------------
# Storage
# --------------------------------------------------------------------------

SCHEMA = """
CREATE TABLE IF NOT EXISTS snapshots (
    id INTEGER PRIMARY KEY,
    ts TEXT NOT NULL,
    account_id TEXT NOT NULL,
    ok INTEGER NOT NULL,
    metrics TEXT,
    error TEXT
);
CREATE INDEX IF NOT EXISTS ix_snap_acct_ts ON snapshots(account_id, ts);
CREATE TABLE IF NOT EXISTS manual_usage (
    id INTEGER PRIMARY KEY,
    ts TEXT NOT NULL,
    sub_id TEXT NOT NULL,
    value REAL NOT NULL,
    unit TEXT,
    lim REAL,
    note TEXT
);
CREATE INDEX IF NOT EXISTS ix_manual_sub_ts ON manual_usage(sub_id, ts);
CREATE TABLE IF NOT EXISTS alerts_sent (
    key TEXT PRIMARY KEY,
    ts TEXT NOT NULL,
    message TEXT
);
"""


def db_connect(cfg: dict) -> sqlite3.Connection:
    Path(cfg["settings"]["db_path"]).parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(cfg["settings"]["db_path"])
    con.row_factory = sqlite3.Row
    con.executescript(SCHEMA)
    return con


def now_utc() -> dt.datetime:
    return dt.datetime.now(UTC)


def iso(t: dt.datetime) -> str:
    return t.astimezone(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


def latest_snapshot(con, account_id: str, ok_only=False):
    q = "SELECT * FROM snapshots WHERE account_id=?"
    if ok_only:
        q += " AND ok=1"
    row = con.execute(q + " ORDER BY ts DESC LIMIT 1", (account_id,)).fetchone()
    if not row:
        return None
    d = dict(row)
    d["metrics"] = json.loads(d["metrics"]) if d["metrics"] else {}
    return d


def latest_manual(con, sub_id: str):
    row = con.execute(
        "SELECT * FROM manual_usage WHERE sub_id=? ORDER BY ts DESC LIMIT 1", (sub_id,)
    ).fetchone()
    return dict(row) if row else None


# --------------------------------------------------------------------------
# Collectors. Each returns a metrics dict:
#   spend_mtd, spend_today        USD spent this calendar month (UTC) / today
#   daily: [{date, usd}]          per-day spend this month
#   by_model: {name: usd}         spend breakdown
#   tokens_by_model: {name: n}    input+output tokens this month
#   balance                       prepaid credit left (USD), if known
#   cap, cap_remaining            provider-side spending cap, if known
# --------------------------------------------------------------------------

def month_start(t: dt.datetime) -> dt.datetime:
    return t.replace(day=1, hour=0, minute=0, second=0, microsecond=0)


def _get(url, headers, params=None):
    r = requests.get(url, headers=headers, params=params, timeout=HTTP_TIMEOUT)
    if r.status_code >= 400:
        raise RuntimeError(f"HTTP {r.status_code} from {urlparse(url).path}: {r.text[:300]}")
    return r.json()


def _paginate(url, headers, params, next_key="next_page", page_param="page", max_pages=20):
    params = dict(params)
    for _ in range(max_pages):
        data = _get(url, headers, params)
        yield data
        if not data.get("has_more") or not data.get(next_key):
            return
        params[page_param] = data[next_key]


def _finish(daily: dict, by_model: dict, today: str) -> dict:
    return {
        "spend_mtd": round(sum(daily.values()), 4),
        "spend_today": round(daily.get(today, 0.0), 4),
        "daily": [{"date": d, "usd": round(v, 4)} for d, v in sorted(daily.items())],
        "by_model": {k: round(v, 4) for k, v in sorted(by_model.items(), key=lambda x: -x[1])},
    }


def collect_anthropic(acct: dict) -> dict:
    """Anthropic Admin API (needs an sk-ant-admin... key)."""
    key = env(acct.get("api_key_env"))
    if not key:
        raise RuntimeError(f"env var {acct.get('api_key_env')} is not set")
    h = {"x-api-key": key, "anthropic-version": "2023-06-01", "User-Agent": "aimon/1.0"}
    base = acct.get("base_url", "https://api.anthropic.com")
    now = now_utc()
    start = month_start(now)
    today = now.strftime("%Y-%m-%d")

    daily, by_model = {}, {}
    params = {
        "starting_at": iso(start),
        "ending_at": iso(now + dt.timedelta(days=1)),
        "group_by[]": "description",
        "limit": 31,
    }
    for page in _paginate(f"{base}/v1/organizations/cost_report", h, params):
        for bucket in page.get("data", []):
            day = str(bucket.get("starting_at", ""))[:10]
            for res in bucket.get("results", []):
                usd = float(res.get("amount") or 0) / 100.0  # amounts are in cents
                daily[day] = daily.get(day, 0.0) + usd
                name = res.get("model") or res.get("description") or res.get("cost_type") or "other"
                by_model[name] = by_model.get(name, 0.0) + usd
    out = _finish(daily, by_model, today)

    tokens = {}
    try:
        uparams = {
            "starting_at": iso(start),
            "ending_at": iso(now + dt.timedelta(days=1)),
            "group_by[]": "model",
            "bucket_width": "1d",
            "limit": 31,
        }
        for page in _paginate(f"{base}/v1/organizations/usage_report/messages", h, uparams):
            for bucket in page.get("data", []):
                for res in bucket.get("results", []):
                    cc = res.get("cache_creation") or {}
                    n = (
                        (res.get("uncached_input_tokens") or 0)
                        + (res.get("cache_read_input_tokens") or 0)
                        + sum(v or 0 for v in cc.values() if isinstance(v, (int, float)))
                        + (res.get("output_tokens") or 0)
                    )
                    m = res.get("model") or "other"
                    tokens[m] = tokens.get(m, 0) + n
    except Exception as e:  # tokens are a nice-to-have
        log.warning("anthropic usage_report failed: %s", e)
    out["tokens_by_model"] = tokens
    return out


def collect_openai(acct: dict) -> dict:
    """OpenAI Platform org Usage/Costs API (needs an admin key)."""
    key = env(acct.get("api_key_env"))
    if not key:
        raise RuntimeError(f"env var {acct.get('api_key_env')} is not set")
    h = {"Authorization": f"Bearer {key}", "Content-Type": "application/json"}
    if acct.get("org_id"):
        h["OpenAI-Organization"] = acct["org_id"]
    base = acct.get("base_url", "https://api.openai.com")
    now = now_utc()
    start = int(month_start(now).timestamp())
    today = now.strftime("%Y-%m-%d")

    daily, by_line = {}, {}
    params = {"start_time": start, "bucket_width": "1d", "limit": 31, "group_by": "line_item"}
    for page in _paginate(f"{base}/v1/organization/costs", h, params):
        for bucket in page.get("data", []):
            day = dt.datetime.fromtimestamp(bucket.get("start_time", 0), UTC).strftime("%Y-%m-%d")
            for res in bucket.get("results", []):
                amt = res.get("amount") or {}
                usd = float(amt.get("value") or 0)
                daily[day] = daily.get(day, 0.0) + usd
                name = res.get("line_item") or "other"
                by_line[name] = by_line.get(name, 0.0) + usd
    out = _finish(daily, by_line, today)

    tokens = {}
    try:
        uparams = {"start_time": start, "bucket_width": "1d", "limit": 31, "group_by": "model"}
        for page in _paginate(f"{base}/v1/organization/usage/completions", h, uparams):
            for bucket in page.get("data", []):
                for res in bucket.get("results", []):
                    m = res.get("model") or "other"
                    tokens[m] = tokens.get(m, 0) + (res.get("input_tokens") or 0) + (res.get("output_tokens") or 0)
    except Exception as e:
        log.warning("openai usage/completions failed: %s", e)
    out["tokens_by_model"] = tokens
    return out


def collect_openrouter(acct: dict) -> dict:
    key = env(acct.get("api_key_env"))
    if not key:
        raise RuntimeError(f"env var {acct.get('api_key_env')} is not set")
    h = {"Authorization": f"Bearer {key}"}
    k = _get("https://openrouter.ai/api/v1/key", h).get("data", {})
    today = now_utc().strftime("%Y-%m-%d")
    out = {
        "spend_mtd": round(float(k.get("usage_monthly") or 0), 4),
        "spend_today": round(float(k.get("usage_daily") or 0), 4),
        "spend_all_time": round(float(k.get("usage") or 0), 4),
        "daily": [{"date": today, "usd": round(float(k.get("usage_daily") or 0), 4)}],
        "by_model": {},
        "cap": k.get("limit"),
        "cap_remaining": k.get("limit_remaining"),
        "cap_reset": k.get("limit_reset"),
        "free_tier": k.get("is_free_tier"),
    }
    try:
        c = _get("https://openrouter.ai/api/v1/credits", h).get("data", {})
        out["balance"] = round(float(c.get("total_credits", 0)) - float(c.get("total_usage", 0)), 4)
    except Exception as e:
        log.info("openrouter /credits unavailable for this key: %s", e)
    return out


def collect_deepseek(acct: dict) -> dict:
    key = env(acct.get("api_key_env"))
    if not key:
        raise RuntimeError(f"env var {acct.get('api_key_env')} is not set")
    d = _get("https://api.deepseek.com/user/balance", {"Authorization": f"Bearer {key}"})
    infos = d.get("balance_infos") or []
    usd = next((i for i in infos if i.get("currency") == "USD"), infos[0] if infos else {})
    return {
        "balance": float(usd.get("total_balance") or 0),
        "balance_currency": usd.get("currency", "USD"),
        "available": d.get("is_available"),
    }


def collect_manual(acct: dict) -> dict:
    """For providers with no usage API: numbers come from `aimon log`."""
    return {"manual": True}


COLLECTORS = {
    "anthropic": collect_anthropic,
    "openai": collect_openai,
    "openrouter": collect_openrouter,
    "deepseek": collect_deepseek,
    "manual": collect_manual,
}


# --------------------------------------------------------------------------
# Subscriptions
# --------------------------------------------------------------------------

CYCLE_MONTHS = {"monthly": 1, "quarterly": 3, "semiannual": 6, "yearly": 12, "annual": 12}


def add_months(d: dt.date, n: int) -> dt.date:
    m = d.month - 1 + n
    y, m = d.year + m // 12, m % 12 + 1
    for day in (d.day, 30, 29, 28):
        try:
            return dt.date(y, m, min(day, 31))
        except ValueError:
            continue
    raise ValueError(d)


def next_renewal(sub: dict, today: dt.date | None = None) -> dt.date | None:
    r = sub.get("renews_on")
    if not r:
        return None
    d = r if isinstance(r, dt.date) else dt.date.fromisoformat(str(r))
    today = today or dt.date.today()
    cycle = str(sub.get("cycle", "monthly")).lower()
    if cycle == "weekly":
        while d < today:
            d += dt.timedelta(days=7)
        return d
    step = CYCLE_MONTHS.get(cycle)
    if not step:
        return d
    while d < today:
        d = add_months(d, step)
    return d


def monthly_cost_usd(sub: dict, fx: dict) -> float | None:
    cost = sub.get("cost")
    if cost is None:
        return None
    cur = str(sub.get("currency", "USD")).upper()
    rate = fx.get(cur)
    if rate is None:
        return None
    cycle = str(sub.get("cycle", "monthly")).lower()
    per_month = float(cost) * (52 / 12 if cycle == "weekly" else 1 / CYCLE_MONTHS.get(cycle, 1))
    return round(per_month * float(rate), 2)


def usage_period_key(sub: dict, t: dt.datetime) -> str:
    p = str(sub.get("limit_period", "monthly")).lower()
    if p == "weekly":
        y, w, _ = t.isocalendar()
        return f"{y}-W{w:02d}"
    if p == "daily":
        return t.strftime("%Y-%m-%d")
    return t.strftime("%Y-%m")


# --------------------------------------------------------------------------
# Alerts
# --------------------------------------------------------------------------

def send_alert(cfg: dict, text: str) -> bool:
    sent = False
    a = cfg.get("alerts", {})
    tg = a.get("telegram") or {}
    if tg.get("enabled"):
        tok, chat = env(tg.get("bot_token_env")), env(tg.get("chat_id_env"))
        if tok and chat:
            try:
                r = requests.post(
                    f"https://api.telegram.org/bot{tok}/sendMessage",
                    json={"chat_id": chat, "text": text, "disable_web_page_preview": True},
                    timeout=HTTP_TIMEOUT,
                )
                sent = sent or r.ok
                if not r.ok:
                    log.error("telegram: HTTP %s %s", r.status_code, r.text[:200])
            except Exception as e:
                log.error("telegram: %s", e)
        else:
            log.error("telegram enabled but token/chat id env vars are missing")
    wh = a.get("webhook") or {}
    if wh.get("enabled"):
        url = env(wh.get("url_env"))
        if url:
            try:
                r = requests.post(url, json={"text": text, "content": text, "source": "aimon"}, timeout=HTTP_TIMEOUT)
                sent = sent or r.ok
            except Exception as e:
                log.error("webhook: %s", e)
    if not sent:
        log.warning("ALERT (not delivered): %s", text)
    return sent


def alert_once(con, cfg: dict, key: str, text: str) -> None:
    if con.execute("SELECT 1 FROM alerts_sent WHERE key=?", (key,)).fetchone():
        return
    log.info("alert: %s", text)
    send_alert(cfg, text)
    con.execute("INSERT OR REPLACE INTO alerts_sent(key, ts, message) VALUES (?,?,?)", (key, iso(now_utc()), text))
    con.commit()


def crossed(used_pct: float, thresholds: list) -> float | None:
    hit = [t for t in sorted(thresholds) if used_pct >= t]
    return hit[-1] if hit else None


def run_checks(con, cfg: dict) -> None:
    s = cfg["settings"]
    th = s["alert_thresholds"]
    now = now_utc()
    month = now.strftime("%Y-%m")
    today = dt.date.today()

    for acct in cfg["api_accounts"]:
        aid, label = acct["id"], acct.get("label", acct["id"])
        snap = latest_snapshot(con, aid)
        if not snap:
            continue
        if not snap["ok"]:
            alert_once(con, cfg, f"{aid}:error:{today}", f"⚠️ {label}: collector failed\n{snap['error'][:300]}")
            continue
        m = snap["metrics"]
        budget = acct.get("monthly_budget")
        if budget and m.get("spend_mtd") is not None:
            pct = m["spend_mtd"] / float(budget)
            t = crossed(pct, th)
            if t is not None:
                alert_once(con, cfg, f"{aid}:budget:{t}:{month}",
                           f"💸 {label}: ${m['spend_mtd']:.2f} of ${budget} monthly budget ({pct:.0%})")
        if m.get("cap") and m.get("cap_remaining") is not None:
            pct = 1 - float(m["cap_remaining"]) / float(m["cap"])
            t = crossed(pct, th)
            if t is not None:
                alert_once(con, cfg, f"{aid}:cap:{t}:{month}",
                           f"🧢 {label}: key cap {pct:.0%} used (${m['cap_remaining']:.2f} of ${m['cap']} left)")
        low = acct.get("low_balance")
        if low is not None and m.get("balance") is not None and m["balance"] < float(low):
            alert_once(con, cfg, f"{aid}:lowbal:{today}",
                       f"🪫 {label}: balance {m['balance']:.2f} {m.get('balance_currency', 'USD')} is below {low}")
        daily_budget = acct.get("daily_budget")
        if daily_budget and m.get("spend_today", 0) >= float(daily_budget):
            alert_once(con, cfg, f"{aid}:daily:{today}",
                       f"📈 {label}: ${m['spend_today']:.2f} spent today (daily limit ${daily_budget})")

    for sub in cfg["subscriptions"]:
        sid, name = sub["id"], sub.get("name", sub["id"])
        nr = next_renewal(sub, today)
        if nr:
            days = (nr - today).days
            for d in s["renewal_reminder_days"]:
                if days == d or (d == min(s["renewal_reminder_days"]) and 0 <= days <= d):
                    cost = f"{sub.get('cost')} {sub.get('currency', 'USD')}" if sub.get("cost") is not None else ""
                    alert_once(con, cfg, f"{sid}:renew:{nr}:{d}",
                               f"🔁 {name} renews in {days} day(s) on {nr} {cost}".strip())
                    break
        mu = latest_manual(con, sid)
        if mu:
            lim = mu["lim"] or sub.get("usage_limit")
            pct = (mu["value"] / 100.0) if mu["unit"] == "%" else (mu["value"] / float(lim) if lim else None)
            if pct is not None:
                t = crossed(pct, th)
                if t is not None:
                    period = usage_period_key(sub, dt.datetime.fromisoformat(mu["ts"].replace("Z", "+00:00")))
                    alert_once(con, cfg, f"{sid}:manual:{t}:{period}",
                               f"📊 {name}: {pct:.0%} of {sub.get('limit_period', 'monthly')} limit used")


# --------------------------------------------------------------------------
# Commands
# --------------------------------------------------------------------------

def cmd_collect(cfg, args) -> int:
    con = db_connect(cfg)
    failures = 0
    for acct in cfg["api_accounts"]:
        if args.only and acct["id"] not in args.only:
            continue
        prov = acct.get("provider", "manual")
        fn = COLLECTORS.get(prov)
        ts = iso(now_utc())
        if not fn:
            log.error("%s: unknown provider %r", acct["id"], prov)
            continue
        try:
            m = fn(acct)
            con.execute("INSERT INTO snapshots(ts, account_id, ok, metrics) VALUES (?,?,1,?)",
                        (ts, acct["id"], json.dumps(m)))
            log.info("%s: ok %s", acct["id"], {k: m[k] for k in ("spend_mtd", "balance", "cap_remaining") if k in m})
        except Exception as e:
            failures += 1
            con.execute("INSERT INTO snapshots(ts, account_id, ok, error) VALUES (?,?,0,?)",
                        (ts, acct["id"], str(e)))
            log.error("%s: %s", acct["id"], e)
        con.commit()
    # keep the DB small: one snapshot per account per hour is plenty after 7 days
    con.execute("""DELETE FROM snapshots WHERE ts < ? AND id NOT IN (
                     SELECT MAX(id) FROM snapshots GROUP BY account_id, substr(ts,1,13))""",
                (iso(now_utc() - dt.timedelta(days=7)),))
    con.commit()
    if not args.no_alerts:
        run_checks(con, cfg)
    return 1 if failures and args.strict else 0


def cmd_log(cfg, args) -> int:
    ids = {s["id"] for s in cfg["subscriptions"]} | {a["id"] for a in cfg["api_accounts"]}
    if args.id not in ids:
        print(f"Unknown id {args.id!r}. Known: {', '.join(sorted(ids))}")
        return 2
    con = db_connect(cfg)
    con.execute("INSERT INTO manual_usage(ts, sub_id, value, unit, lim, note) VALUES (?,?,?,?,?,?)",
                (iso(now_utc()), args.id, args.value, args.unit, args.limit, args.note))
    con.commit()
    print(f"Logged {args.value}{args.unit or ''} for {args.id}")
    run_checks(con, cfg)
    return 0


def build_state(cfg) -> dict:
    con = db_connect(cfg)
    fx = cfg["settings"]["fx_to_usd"]
    today = dt.date.today()
    apis = []
    for a in cfg["api_accounts"]:
        snap = latest_snapshot(con, a["id"])
        good = snap if snap and snap["ok"] else latest_snapshot(con, a["id"], ok_only=True)
        mu = latest_manual(con, a["id"])
        apis.append({
            "id": a["id"], "label": a.get("label", a["id"]), "provider": a.get("provider"),
            "budget": a.get("monthly_budget"), "console_url": a.get("console_url"),
            "notes": a.get("notes"),
            "metrics": good["metrics"] if good else {},
            "updated": good["ts"] if good else None,
            "error": snap["error"] if snap and not snap["ok"] else None,
            "manual": mu,
        })
    subs = []
    for sb in cfg["subscriptions"]:
        nr = next_renewal(sb, today)
        mu = latest_manual(con, sb["id"])
        if mu and not mu["lim"] and mu["unit"] != "%":
            mu["lim"] = sb.get("usage_limit")
        subs.append({
            "id": sb["id"], "name": sb.get("name", sb["id"]), "vendor": sb.get("vendor", ""),
            "category": sb.get("category", "other"), "plan": sb.get("plan", ""),
            "cost": sb.get("cost"), "currency": sb.get("currency", "USD"),
            "cycle": sb.get("cycle", "monthly"),
            "monthly_usd": monthly_cost_usd(sb, fx),
            "next_renewal": nr.isoformat() if nr else None,
            "days_left": (nr - today).days if nr else None,
            "limits": sb.get("limits", ""), "usage_url": sb.get("usage_url"),
            "limit_period": sb.get("limit_period"),
            "manual": mu,
        })
    api_mtd = sum((x["metrics"].get("spend_mtd") or 0) for x in apis)
    fixed = sum((x["monthly_usd"] or 0) for x in subs)
    recent = [dict(r) for r in con.execute("SELECT * FROM alerts_sent ORDER BY ts DESC LIMIT 15")]
    return {
        "generated": iso(now_utc()), "apis": apis, "subscriptions": subs,
        "totals": {"api_mtd_usd": round(api_mtd, 2), "subscriptions_monthly_usd": round(fixed, 2),
                   "all_usd": round(api_mtd + fixed, 2)},
        "alerts": recent,
    }


def cmd_status(cfg, args) -> int:
    st = build_state(cfg)
    if args.json:
        print(json.dumps(st, indent=2))
        return 0
    print(f"\nAPI ACCOUNTS (month to date, generated {st['generated']})")
    for a in st["apis"]:
        m = a["metrics"]
        parts = []
        if "spend_mtd" in m:
            parts.append(f"${m['spend_mtd']:.2f}" + (f" / ${a['budget']}" if a["budget"] else ""))
        if m.get("balance") is not None:
            parts.append(f"balance {m['balance']:.2f}")
        if m.get("cap"):
            parts.append(f"cap left {m.get('cap_remaining')}/{m['cap']}")
        if a["error"]:
            parts.append(f"ERROR: {a['error'][:80]}")
        print(f"  {a['label']:<28} {'  '.join(parts) or '(no data yet)'}")
    print("\nSUBSCRIPTIONS")
    for s in sorted(st["subscriptions"], key=lambda x: (x["days_left"] is None, x["days_left"] or 0)):
        cost = f"{s['cost']} {s['currency']}/{s['cycle']}" if s["cost"] is not None else ""
        ren = f"renews {s['next_renewal']} ({s['days_left']}d)" if s["next_renewal"] else ""
        mu = s["manual"]
        use = f"  usage {mu['value']}{mu['unit'] or ''}" if mu else ""
        print(f"  {s['name']:<28} {cost:<22} {ren}{use}")
    t = st["totals"]
    print(f"\nTOTAL  API this month ${t['api_mtd_usd']}  +  subscriptions ${t['subscriptions_monthly_usd']}/mo"
          f"  =  ${t['all_usd']}\n")
    return 0


def cmd_test_alert(cfg, args) -> int:
    ok = send_alert(cfg, "✅ aimon test alert: your usage monitor can reach you.")
    print("sent" if ok else "not sent (check alerts config and env vars)")
    return 0 if ok else 1


# --------------------------------------------------------------------------
# Dashboard
# --------------------------------------------------------------------------

def cmd_serve(cfg, args) -> int:
    d = cfg["settings"]["dashboard"]
    host = args.host or d.get("host", "127.0.0.1")
    port = args.port or int(d.get("port", 8787))
    token = env(d.get("token_env"))
    page = (HERE / "dashboard.html").read_text()

    class H(BaseHTTPRequestHandler):
        def log_message(self, fmt, *a):
            log.debug(fmt, *a)

        def _authed(self) -> bool:
            if not token:
                return True
            q = parse_qs(urlparse(self.path).query).get("token", [""])[0]
            if q and hmac.compare_digest(q, token):
                return True
            auth = self.headers.get("Authorization", "")
            if auth.startswith("Basic "):
                try:
                    pw = base64.b64decode(auth[6:]).decode().split(":", 1)[1]
                    return hmac.compare_digest(pw, token)
                except Exception:
                    return False
            if auth.startswith("Bearer "):
                return hmac.compare_digest(auth[7:], token)
            return False

        def _send(self, code, body: bytes, ctype):
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            path = urlparse(self.path).path
            if path == "/healthz":
                return self._send(200, b"ok", "text/plain")
            if not self._authed():
                self.send_response(401)
                self.send_header("WWW-Authenticate", 'Basic realm="aimon"')
                self.end_headers()
                return
            if path == "/api/state":
                return self._send(200, json.dumps(build_state(cfg)).encode(), "application/json")
            if path in ("/", "/index.html"):
                return self._send(200, page.encode(), "text/html; charset=utf-8")
            self._send(404, b"not found", "text/plain")

        def do_POST(self):
            if not self._authed():
                return self._send(401, b"unauthorized", "text/plain")
            path = urlparse(self.path).path
            n = int(self.headers.get("Content-Length") or 0)
            try:
                body = json.loads(self.rfile.read(n) or b"{}")
            except ValueError:
                return self._send(400, b"bad json", "text/plain")
            if path == "/api/log":
                ns = argparse.Namespace(id=str(body.get("id", "")), value=float(body.get("value", 0)),
                                        unit=body.get("unit") or None, limit=body.get("limit"),
                                        note=body.get("note"))
                rc = cmd_log(cfg, ns)
                return self._send(200 if rc == 0 else 400, json.dumps({"ok": rc == 0}).encode(), "application/json")
            if path == "/api/collect":
                cmd_collect(cfg, argparse.Namespace(only=None, no_alerts=False, strict=False))
                return self._send(200, b'{"ok":true}', "application/json")
            self._send(404, b"not found", "text/plain")

    if host not in ("127.0.0.1", "localhost") and not token:
        log.warning("Dashboard is listening on %s without a token. Set settings.dashboard.token_env.", host)
    log.info("dashboard on http://%s:%s", host, port)
    ThreadingHTTPServer((host, port), H).serve_forever()
    return 0


def main(argv=None) -> int:
    p = argparse.ArgumentParser(prog="aimon", description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("-c", "--config", help="path to config.yaml (default: next to aimon.py)")
    p.add_argument("-v", "--verbose", action="store_true")
    sp = p.add_subparsers(dest="cmd", required=True)

    c = sp.add_parser("collect", help="poll APIs, store snapshot, send alerts")
    c.add_argument("--only", nargs="*", help="only these account ids")
    c.add_argument("--no-alerts", action="store_true")
    c.add_argument("--strict", action="store_true", help="exit 1 if any collector fails")

    s = sp.add_parser("serve", help="run the dashboard")
    s.add_argument("--host")
    s.add_argument("--port", type=int)

    st = sp.add_parser("status", help="terminal summary")
    st.add_argument("--json", action="store_true")

    lg = sp.add_parser("log", help="record a manual usage reading")
    lg.add_argument("id")
    lg.add_argument("value", type=float)
    lg.add_argument("--unit", help='e.g. "%" for percent of limit, "msgs", "credits"')
    lg.add_argument("--limit", type=float, help="the limit the value is measured against")
    lg.add_argument("--note")

    sp.add_parser("test-alert", help="send a test alert")

    args = p.parse_args(argv)
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.INFO,
                        format="%(asctime)s %(levelname)s %(message)s")
    cfg = load_config(args.config)
    return {"collect": cmd_collect, "serve": cmd_serve, "status": cmd_status,
            "log": cmd_log, "test-alert": cmd_test_alert}[args.cmd](cfg, args)


if __name__ == "__main__":
    sys.exit(main())
