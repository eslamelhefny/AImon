#!/bin/sh
# Runs the collector on a loop and serves the dashboard.
mkdir -p /data
[ -f /data/config.yaml ] || cp /app/config.example.yaml /data/config.yaml
(
  while true; do
    python /app/aimon.py -c /data/config.yaml collect || true
    sleep "${COLLECT_INTERVAL:-1800}"
  done
) &
exec python /app/aimon.py -c /data/config.yaml serve --host 0.0.0.0 --port 8787
