#!/usr/bin/env bash
# Install aimon on a systemd Linux VPS. Run from the project folder: sudo bash deploy/install.sh
set -euo pipefail

DEST=/opt/aimon
SRC="$(cd "$(dirname "$0")/.." && pwd)"

id aimon >/dev/null 2>&1 || useradd --system --home "$DEST" --shell /usr/sbin/nologin aimon
mkdir -p "$DEST/data"
cp "$SRC/aimon.py" "$SRC/dashboard.html" "$SRC/requirements.txt" "$DEST/"
[ -f "$DEST/config.yaml" ] || cp "$SRC/config.example.yaml" "$DEST/config.yaml"
[ -f "$DEST/.env" ] || cp "$SRC/.env.example" "$DEST/.env"

python3 -m venv "$DEST/.venv"
"$DEST/.venv/bin/pip" install -q -r "$DEST/requirements.txt"

chown -R aimon:aimon "$DEST"
chmod 600 "$DEST/.env"

cp "$SRC"/deploy/aimon-*.service "$SRC"/deploy/aimon-collect.timer /etc/systemd/system/
systemctl daemon-reload
systemctl enable --now aimon-collect.timer aimon-web.service

echo
echo "Installed to $DEST"
echo "Next: edit $DEST/config.yaml and $DEST/.env, then:"
echo "  sudo -u aimon $DEST/.venv/bin/python $DEST/aimon.py test-alert"
echo "  sudo systemctl start aimon-collect && sudo systemctl restart aimon-web"
echo "  ssh -L 8787:127.0.0.1:8787 <vps>   then open http://localhost:8787"
